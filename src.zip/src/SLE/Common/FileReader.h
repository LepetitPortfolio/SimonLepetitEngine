#pragma once
#include "Error.h"
#include "String.h"

#include <fstream>
#include <vector>

#ifndef ENGINE_DIR
#define ENGINE_DIR "../"
#endif

class FileReader
{
public:

	/**
	* Lit le contenu d'un fichier binaire et le retourne sous forme de tableau de caract�res.
	*
	* @param _Filename Chemin du fichier � lire.
	* @return std::vector<char> Contenu binaire du fichier.
	*
	* @details
	* - Ouvre le fichier en mode binaire (`std::ios::binary`) et se positionne � la fin (`std::ios::ate`) pour obtenir sa taille.
	* - Si le fichier ne s'ouvre pas, affiche une erreur via `Err()`.
	* - R�cup�re la taille du fichier avec `tellg()` (position actuelle dans le fichier).
	* - Alloue un `std::vector<char>` de la taille du fichier.
	* - Se repositionne au d�but du fichier avec `seekg(0)`.
	* - Lit le contenu du fichier dans le `buffer` avec `file.read()`.
	* - Ferme le fichier et retourne le buffer.
	*/
	static std::vector<char> ReadBinaryFile(const std::string& _Ffilename);

	/**
	* R�cup�re le dossier racine de l'application.
	*
	* @return String Chemin du dossier racine.
	*
	* @details
	* - Si `m_RootFolder` est vide, calcule le chemin du dossier racine :
	*   - R�cup�re le chemin du r�pertoire courant avec `_getcwd(NULL, 0)`.
	*   - D�coupe le chemin en sous-dossiers avec `Split('\\')` (s�parateur Windows).
	*   - Reconstruit le chemin en ignorant les deux derniers dossiers (probablement pour remonter � la racine du projet).
	*   - Stocke le r�sultat dans `m_RootFolder` pour les appels futurs.
	* - Retourne `m_RootFolder`.
	*/
	static String GetRootFolder();

private:

	/**
	* Variable statique de la classe FileReader.
	* Stocke le chemin du dossier racine de l'application.
	* Initialis�e � vide, elle est remplie � la premi�re appel de GetRootFolder().
	*/
	static String m_RootFolder;
	
};