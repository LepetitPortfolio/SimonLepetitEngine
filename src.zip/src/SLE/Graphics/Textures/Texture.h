#pragma once
#include "TextureBase.h"

class Texture : public TextureBase
{
public:
	Texture();
	Texture(const char* _TexturePath);

	Texture(const Texture&) = delete;
	Texture& operator=(const Texture&) = delete;
	virtual ~Texture() override;

	inline VkSampler GetTextureSampler() { return m_TextureSampler; }
	
	void CleanupTexture();

protected:
	VkSampler m_TextureSampler;

	void LoadTexture(const char* _FilePath);

	/**
	* Cr�e une image de texture Vulkan � partir d'un fichier image.
	* �tapes :
	* 1. Charge les pixels de l'image avec stbi_load (force le format RGBA).
	* 2. Calcule le nombre de niveaux de mipmap en fonction des dimensions de l'image.
	* 3. Cr�e un buffer de staging (m�moire accessible par le CPU) pour transf�rer les pixels vers le GPU.
	* 4. Copie les pixels dans le buffer de staging via vkMapMemory.
	* 5. Cr�e l'image Vulkan finale avec les param�tres adapt�s (taille, format, usage pour �chantillonnage et transfert).
	* 6. Transitionne le layout de l'image de UNDEFINED � TRANSFER_DST_OPTIMAL pour permettre la copie.
	* 7. Copie les donn�es du buffer de staging vers l'image Vulkan.
	* 8. G�n�re les mipmaps pour l'image.
	* 9. Lib�re le buffer de staging et sa m�moire.
	* _FilePath : Chemin vers le fichier d'image � charger.
	* _Texture : R�f�rence vers l'objet Texture � remplir (stocke l'image, la m�moire, et les infos de texture).
	*/
	void CreateTextureImage(const char* _FilePath);

	/**
	* Cr�e un �chantillonneur (VkSampler) pour une texture.
	* Configure les param�tres suivants :
	* - Filtrage : Lin�aire pour la magnification et la minification.
	* - Adressage : R�p�tition (REPEAT) sur les axes U, V, et W.
	* - Anisotropie : Activ�e avec la valeur maximale support�e par le GPU.
	* - Mode de mipmap : Lin�aire.
	* - Couleur de bordure : Noir opaque.
	* - Plage de LOD : De 0.0 � VK_LOD_CLAMP_NONE (tous les niveaux de mipmap).
	* _Texture : R�f�rence vers l'objet Texture dont on veut cr�er l'�chantillonneur.
	*/
	void CreateTextureSampler();

};