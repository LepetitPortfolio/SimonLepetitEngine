#pragma once

#include <array>
#include <type_traits>

#include <cassert>
#include <cstddef>


/**
 * Structure h�ritant de std::array<Value, Count> pour permettre un acc�s index� via des valeurs d'�num�ration (Enum).
 * @tparam Enum Type �num�r� utilis� comme cl� pour acc�der aux �l�ments du tableau.
 * @tparam Value Type des valeurs stock�es dans le tableau.
 * @tparam Count Nombre d'�l�ments dans le tableau.
 *
 * Cette structure permet d'utiliser des valeurs d'�num�ration comme indices pour acc�der aux �l�ments du tableau,
 * tout en garantissant la s�curit� des acc�s via des assertions.
 */
template<typename Enum, typename Value, size_t Count>
struct EnumArray : public std::array<Value, Count>
{
	/**
	 * V�rification statique : le premier param�tre de template doit �tre un type �num�r�.
	 */
	static_assert(std::is_enum_v<Enum>, "EnumArray requires an enum type as the first template parameter.");

	/**
	 * Op�rateur d'acc�s non-const pour acc�der � un �l�ment du tableau via une valeur d'�num�ration.
	 *
	 * @param _Key Valeur de l'�num�ration utilis�e comme index.
	 * @return R�f�rence vers l'�l�ment du tableau correspondant � l'index de l'�num�ration.
	 *
	 * @details
	 * - Convertit la valeur de l'�num�ration (_Key) en un index de type std::size_t.
	 * - V�rifie que l'index est valide (inf�rieur � Count) via une assertion.
	 * - Utilise l'op�rateur [] de std::array pour acc�der � l'�l�ment.
	 */
	constexpr Value& operator[](Enum _Key)
	{
		const auto index = static_cast<std::size_t>(_Key);
		assert(index < Count && "Enum value out of bounds.");
		return std::array<Value, Count>::operator[](index);
	}

	/**
	 * Op�rateur d'acc�s const pour acc�der � un �l�ment du tableau via une valeur d'�num�ration.
	 *
	 * @param _Key Valeur de l'�num�ration utilis�e comme index.
	 * @return R�f�rence constante vers l'�l�ment du tableau correspondant � l'index de l'�num�ration.
	 *
	 * @details
	 * - Identique � l'op�rateur non-const, mais retourne une r�f�rence constante pour garantir l'immuabilit�.
	 * - Convertit la valeur de l'�num�ration (_Key) en un index de type std::size_t.
	 * - V�rifie que l'index est valide (inf�rieur � Count) via une assertion.
	 * - Utilise l'op�rateur [] de std::array pour acc�der � l'�l�ment.
	 */
	constexpr const Value& operator[](Enum _Key) const
	{
		const auto index = static_cast<std::size_t>(_Key);
		assert(index < Count && "Enum value out of bounds.");
		return std::array<Value, Count>::operator[](index);
	}
};