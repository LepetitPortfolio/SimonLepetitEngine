#pragma once
#include <functional>
#include <algorithm>


template<typename... Args>
class Delegate
{
public:

	/**
	* Type alias pour std::function avec la signature void(Args...).
	* Permet de d�finir le type de fonction que le Delegate peut stocker.
	*/
	using FuncType = std::function<void(Args...)>;

	/**
	* Lie une fonction au Delegate.
	* @param _Function Fonction � lier (de type FuncType).
	*
	* @details
	* Stocke la fonction `_Function` dans `m_functionDelegate`.
	* Si `_Function` est `nullptr`, le Delegate ne fera rien lors de l'appel.
	*/
	void Bind(const FuncType& _Function)
	{
		m_functionDelegate = _Function;
	}

	/**
	* R�initialise le Delegate en supprimant la fonction li�e.
	*
	* @details
	* D�finit `m_functionDelegate` � `nullptr`, ce qui signifie que le Delegate ne fera rien lors de l'appel.
	*/
	void Clear() 
	{
		m_functionDelegate = nullptr;
	}

	bool IsValid()
	{
		if (!m_functionDelegate)
		{
			return false;
		}
		return true;
	}

	/**
	* Ex�cute la fonction li�e avec les arguments fournis.
	* @param _Args Arguments � passer � la fonction.
	* @return R�sultat de type void. Si aucune fonction n'est li�e, retourne une valeur par d�faut de type void.
	*
	* @details
	* - V�rifie si `m_functionDelegate` est valide (non nul).
	* - Si `m_functionDelegate` est nul, retourne une valeur par d�faut de type `void` (ex: `0` pour `int`, `false` pour `bool`, `nullptr` pour les pointeurs).
	* - Sinon, appelle `m_functionDelegate` avec les arguments `_Args...` et retourne le r�sultat.
	*/
	void Execute(Args... _Args) const
	{
		if(!m_functionDelegate)
		{
			return;
		}
		m_functionDelegate(_Args...);
	}

	/**
	* Op�rateur d'appel de fonction. Permet d'utiliser le Delegate comme une fonction.
	* @param _Args Arguments � passer � la fonction.
	* @return R�sultat de type void (identique � Execute).
	*
	* @details
	* Appelle `Execute(_Args...)` pour ex�cuter la fonction li�e.
	* Cela permet d'utiliser le Delegate de mani�re transparente, comme une fonction normale.
	*/
	void operator()(Args... _Args) const
	{
		Execute(_Args...);
	}

	/**
	* Op�rateur d'affectation. Permet de lier une fonction au Delegate en utilisant l'op�rateur `=`.
	* @param _Function Fonction � lier (de type FuncType).
	*
	* @details
	* Appelle `Bind(_Function)` pour lier la fonction au Delegate.
	* Cela permet une syntaxe plus naturelle pour lier une fonction.
	*/
	void operator=(const FuncType& _Function)
	{
		Bind(_Function);
	}

private:

	/**
	* Fonction stock�e par le Delegate.
	* @details
	* `m_functionDelegate` est une instance de `std::function<void(Args...)>` qui stocke la fonction li�e.
	* Si `m_functionDelegate` est `nullptr`, le Delegate ne fera rien lors de l'appel.
	*/
	FuncType m_functionDelegate;
};