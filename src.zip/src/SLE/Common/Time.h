#pragma once
#include <chrono>
#include <cstdint>

class Time
{
public:

	Time() = default;

	/**
	* Constructeur de conversion depuis une dur�e std::chrono.
	*
	* @tparam Rep Type repr�sentant le type de la valeur de la dur�e (ex: int, float, long long).
	* @tparam Period Type repr�sentant la p�riode de la dur�e (ex: std::ratio<1>, std::milli, std::micro).
	* @param _Duration Dur�e std::chrono � convertir en objet Time.
	*
	* @details
	* Ce constructeur permet d'initialiser un objet `Time` � partir de n'importe quelle dur�e
	* d�finie par `std::chrono::duration<Rep, Period>`. Il stocke simplement la dur�e pass�e en param�tre
	* dans le membre `m_Duration` de la classe `Time`.
	*
	* @note
	* Ce constructeur est marqu� `inline` pour �viter les surco�ts d'appel de fonction.
	* Il est �galement implicite, ce qui permet une conversion automatique depuis `std::chrono::duration`.
	*/
	template<typename Rep, typename Period>
	Time(const std::chrono::duration<Rep, Period>& _Duration);


	/**
	* Convertit la dur�e en secondes (float).
	* @return Dur�e en secondes (pr�cision flottante).
	*
	* @details
	* Utilise `std::chrono::duration<float>` pour convertir la dur�e interne (en microsecondes) en secondes.
	*/
	float GetTimeInSeconds() const;

	/**
	* Convertit la dur�e en millisecondes (entier 32 bits).
	* @return Dur�e en millisecondes.
	*
	* @details
	* Utilise `std::chrono::duration_cast` pour convertir la dur�e en millisecondes.
	*/
	std::int32_t  GetTimeInMilliseconds() const;

	/**
	* Convertit la dur�e en microsecondes (entier 64 bits).
	* @return Dur�e en microsecondes.
	*
	* @details
	* Retourne directement le compteur de la dur�e interne, qui est en microsecondes.
	*/
	std::int64_t GetTimeInMicroseconds() const;

	/**
	* Retourne la dur�e interne sous forme de `std::chrono::microseconds`.
	* @return Dur�e en microsecondes (type `std::chrono::microseconds`).
	*/
	std::chrono::microseconds GetDuration() const;

	/**
	* Op�rateur de conversion vers une dur�e std::chrono.
	*
	* @tparam Rep Type repr�sentant le type de la valeur de la dur�e (ex: int, float, long long).
	* @tparam Period Type repr�sentant la p�riode de la dur�e (ex: std::ratio<1>, std::milli, std::micro).
	* @return std::chrono::duration<Rep, Period> Dur�e std::chrono �quivalente � l'objet Time.
	*
	* @details
	* Cet op�rateur permet de convertir un objet `Time` vers n'importe quelle dur�e `std::chrono::duration<Rep, Period>`.
	* Il retourne simplement le membre `m_Duration` de la classe `Time`, qui est d�j� de type `std::chrono::duration`.
	*
	* @note
	* - Cet op�rateur est marqu� `inline` pour �viter les surco�ts d'appel de fonction.
	* - Il est �galement implicite, ce qui permet une conversion automatique vers `std::chrono::duration`.
	* - La conversion est **g�n�rique** : elle fonctionne pour n'importe quel type `Rep` et `Period`.
	*/
	template<typename Rep, typename Period>
	operator std::chrono::duration<Rep, Period>() const;

	/**
	* Variable statique repr�sentant une dur�e nulle (0 microsecondes).
	* Initialis�e en ligne pour �viter les probl�mes de d�finition multiple.
	*/
	static const Time m_ZeroTime;

private:

	std::chrono::microseconds m_Duration{};
};

/**
 * Cr�e un objet `Time` � partir d'une dur�e en secondes (float).
 * @param _Amount Dur�e en secondes.
 * @return Objet `Time` correspondant.
 *
 * @details
 * Convertit la dur�e en secondes en microsecondes pour le stockage interne.
 */
Time Seconds(float _Amount);

/**
 * Cr�e un objet `Time` � partir d'une dur�e en millisecondes.
 * @param _Amount Dur�e en millisecondes.
 * @return Objet `Time` correspondant.
 */
Time Milliseconds(std::int32_t _Amount);

/**
 * Cr�e un objet `Time` � partir d'une dur�e en microsecondes.
 * @param _Amount Dur�e en microsecondes.
 * @return Objet `Time` correspondant.
 */
Time Microseconds(std::int64_t _Amount);

/**
 * V�rifie si deux dur�es sont �gales.
 * @param _Left Premi�re dur�e.
 * @param _Right Deuxi�me dur�e.
 * @return true si les dur�es sont �gales, false sinon.
 */
bool operator==(Time _Left, Time _Right);

/**
 * V�rifie si deux dur�es sont diff�rentes.
 * @param _Left Premi�re dur�e.
 * @param _Right Deuxi�me dur�e.
 * @return true si les dur�es sont diff�rentes, false sinon.
 */
bool operator!=(Time _Left, Time _Right);

/**
 * V�rifie si une dur�e est strictement inf�rieure � une autre.
 * @param _Left Premi�re dur�e.
 * @param _Right Deuxi�me dur�e.
 * @return true si _Left < _Right, false sinon.
 */
bool operator<(Time _Left, Time _Right);

/**
 * V�rifie si une dur�e est inf�rieure ou �gale � une autre.
 * @param _Left Premi�re dur�e.
 * @param _Right Deuxi�me dur�e.
 * @return true si _Left <= _Right, false sinon.
 */
bool operator<=(Time _Left, Time _Right);

/**
 * V�rifie si une dur�e est strictement sup�rieure � une autre.
 * @param _Left Premi�re dur�e.
 * @param _Right Deuxi�me dur�e.
 * @return true si _Left > _Right, false sinon.
 */
bool operator>(Time _Left, Time _Right);

/**
 * V�rifie si une dur�e est sup�rieure ou �gale � une autre.
 * @param _Left Premi�re dur�e.
 * @param _Right Deuxi�me dur�e.
 * @return true si _Left >= _Right, false sinon.
 */
bool operator>=(Time _Left, Time _Right);

/**
 * Additionne deux dur�es.
 * @param _Left Premi�re dur�e.
 * @param _Right Deuxi�me dur�e.
 * @return Nouvelle dur�e �gale � la somme des deux dur�es.
 */
Time operator+(Time _Left, Time _Right);

/**
 * Soustrait deux dur�es.
 * @param _Left Premi�re dur�e.
 * @param _Right Deuxi�me dur�e.
 * @return Nouvelle dur�e �gale � la diff�rence des deux dur�es.
 */
Time operator-(Time _Left, Time _Right);

/**
 * Ajoute une dur�e � une autre (version avec affectation).
 * @param _Left Dur�e � modifier.
 * @param _Right Dur�e � ajouter.
 * @return R�f�rence vers la dur�e modifi�e.
 *
 * @note Cette fonction semble contenir une erreur : elle retourne `_Left` par valeur au lieu de `Time&`.
 * Elle devrait probablement �tre : `Time& operator+=(Time& _Left, Time _Right)`.
 */
Time& operator+=(Time _Left, Time _Right);

/**
 * Soustrait une dur�e � une autre (version avec affectation).
 * @param _Left Dur�e � modifier.
 * @param _Right Dur�e � soustraire.
 * @return R�f�rence vers la dur�e modifi�e.
 *
 * @note Cette fonction semble contenir une erreur : elle retourne `_Left` par valeur au lieu de `Time&`.
 * Elle devrait probablement �tre : `Time& operator-=(Time& _Left, Time _Right)`.
 */
Time& operator-=(Time _Left, Time _Right);

/**
 * Multiplie une dur�e par un facteur flottant.
 * @param _Left Dur�e � multiplier.
 * @param _Right Facteur de multiplication.
 * @return Nouvelle dur�e �gale � _Left * _Right.
 */
Time operator*(Time _Left, float _Right);

/**
 * Multiplie un facteur flottant par une dur�e.
 * @param _Left Facteur de multiplication.
 * @param _Right Dur�e � multiplier.
 * @return Nouvelle dur�e �gale � _Left * _Right.
 */
Time operator*(float _Left, Time _Right);

/**
 * Multiplie une dur�e par un facteur entier (64 bits).
 * @param _Left Dur�e � multiplier.
 * @param _Right Facteur de multiplication.
 * @return Nouvelle dur�e �gale � _Left * _Right.
 */
Time operator*(Time _Left, int64_t _Right);

/**
 * Multiplie un facteur entier (64 bits) par une dur�e.
 * @param _Left Facteur de multiplication.
 * @param _Right Dur�e � multiplier.
 * @return Nouvelle dur�e �gale � _Left * _Right.
 */
Time operator*(int64_t _Left, Time _Right);

/**
 * Multiplie une dur�e par un facteur flottant (version avec affectation).
 * @param _Left Dur�e � modifier.
 * @param _Right Facteur de multiplication.
 * @return R�f�rence vers la dur�e modifi�e.
 *
 * @note Cette fonction semble contenir une erreur : elle retourne `_Left` par valeur au lieu de `Time&`.
 * Elle devrait probablement �tre : `Time& operator*=(Time& _Left, float _Right)`.
 */
Time& operator*=(Time _Left, float _Right);

/**
 * Multiplie une dur�e par un facteur entier (64 bits) (version avec affectation).
 * @param _Left Dur�e � modifier.
 * @param _Right Facteur de multiplication.
 * @return R�f�rence vers la dur�e modifi�e.
 *
 * @note Cette fonction semble contenir une erreur : elle retourne `_Left` par valeur au lieu de `Time&`.
 * Elle devrait probablement �tre : `Time& operator*=(Time& _Left, int64_t _Right)`.
 */
Time& operator*=(Time _Left, int64_t _Right);

/**
 * Divise une dur�e par un facteur flottant.
 * @param _Left Dur�e � diviser.
 * @param _Right Facteur de division.
 * @return Nouvelle dur�e �gale � _Left / _Right.
 * @throws assert Si _Right est �gal � 0 (division par z�ro).
 */
Time operator/(Time _Left, float _Right);

/**
 * Divise un facteur flottant par une dur�e.
 * @param _Left Facteur de division.
 * @param _Right Dur�e � diviser.
 * @return Nouvelle dur�e �gale � _Left / _Right.
 * @throws assert Si _Right est �gal � 0 (division par z�ro).
 */
Time operator/(float _Left, Time _Right);

/**
 * Divise une dur�e par un facteur entier (64 bits).
 * @param _Left Dur�e � diviser.
 * @param _Right Facteur de division.
 * @return Nouvelle dur�e �gale � _Left / _Right.
 * @throws assert Si _Right est �gal � 0 (division par z�ro).
 */
Time operator/(Time _Left, int64_t _Right);

/**
 * Divise un facteur entier (64 bits) par une dur�e.
 * @param _Left Facteur de division.
 * @param _Right Dur�e � diviser.
 * @return Nouvelle dur�e �gale � _Left / _Right.
 * @throws assert Si _Right est �gal � 0 (division par z�ro).
 */
Time operator/(int64_t _Left, Time _Right);

/**
 * Divise une dur�e par un facteur flottant (version avec affectation).
 * @param _Left Dur�e � modifier.
 * @param _Right Facteur de division.
 * @return R�f�rence vers la dur�e modifi�e.
 * @throws assert Si _Right est �gal � 0 (division par z�ro).
 *
 * @note Cette fonction semble contenir une erreur : elle retourne `_Left` par valeur au lieu de `Time&`.
 * Elle devrait probablement �tre : `Time& operator/=(Time& _Left, float _Right)`.
 */
Time& operator/=(Time _Left, float _Right);

/**
 * Divise une dur�e par un facteur entier (64 bits) (version avec affectation).
 * @param _Left Dur�e � modifier.
 * @param _Right Facteur de division.
 * @return R�f�rence vers la dur�e modifi�e.
 * @throws assert Si _Right est �gal � 0 (division par z�ro).
 *
 * @note Cette fonction semble contenir une erreur : elle retourne `_Left` par valeur au lieu de `Time&`.
 * Elle devrait probablement �tre : `Time& operator/=(Time& _Left, int64_t _Right)`.
 */
Time& operator/=(Time _Left, int64_t _Right);

/**
 * Divise deux dur�es et retourne le r�sultat sous forme de float (rapport).
 * @param _Left Dur�e dividende.
 * @param _Right Dur�e diviseur.
 * @return Rapport des deux dur�es (en secondes).
 * @throws assert Si _Right est �gal � 0 (division par z�ro).
 */
float operator/(Time _Left, Time _Right);

/**
 * Calcule le modulo de deux dur�es.
 * @param _Left Dur�e dividende.
 * @param _Right Dur�e diviseur.
 * @return Reste de la division de _Left par _Right (en microsecondes).
 * @throws assert Si _Right est �gal � 0 (modulo par z�ro).
 */
Time operator%(Time _Left, Time _Right);

/**
 * Calcule le modulo de deux dur�es (version avec affectation).
 * @param _Left Dur�e � modifier.
 * @param _Right Dur�e diviseur.
 * @return R�f�rence vers la dur�e modifi�e.
 * @throws assert Si _Right est �gal � 0 (modulo par z�ro).
 *
 * @note Cette fonction semble contenir une erreur : elle retourne `_Left` par valeur au lieu de `Time&`.
 * Elle devrait probablement �tre : `Time& operator%=(Time& _Left, Time _Right)`.
 */
Time& operator%=(Time _Left, Time _Right);

#include "Time.inl"