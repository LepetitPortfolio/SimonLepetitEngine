#pragma once
#define GLFW_INCLUDE_VULKAN
#include <GLFW/glfw3.h>
#include <vulkan/vulkan.h>

#include <string>


const uint32_t WIDTH = 1600;
const uint32_t HEIGHT = 900;


class WindowPlatform
{
public:
	WindowPlatform() = default;

	/**
	* Destructeur de la classe WindowPlatform.
	*
	* @details
	* Appelle la m�thode `Cleanup()` pour lib�rer les ressources allou�es par la fen�tre GLFW.
	* Cela garantit que la fen�tre et les ressources associ�es sont correctement nettoy�es lorsque l'objet `WindowPlatform` est d�truit.
	*/
	~WindowPlatform();

	WindowPlatform(const WindowPlatform&) = delete;
	WindowPlatform& operator=(const WindowPlatform&) = delete;

	/**
	* Retourne le pointeur vers la fen�tre GLFW.
	* @return Pointeur vers la fen�tre GLFW.
	*/
	GLFWwindow* GetWindow() { return m_Window; }

	bool ShouldClose() { return glfwWindowShouldClose(m_Window); }
	VkExtent2D GetExtent() { return VkExtent2D{ static_cast<uint32_t>(m_Width), static_cast<uint32_t>(m_Height) }; }
	bool WasWindowResized() { return m_FramebufferResized; }
	void ResetWindowResizedFlag() { m_FramebufferResized = false; }

	/**
	* Initialise la fen�tre GLFW.
	*
	* @details
	* - **Initialisation de GLFW** : Appelle `glfwInit()` pour initialiser la biblioth�que GLFW.
	* - **Configuration de la fen�tre** :
	*   - D�finit l'hint `GLFW_CLIENT_API` � `GLFW_NO_API` pour indiquer que la fen�tre ne sera pas utilis�e avec OpenGL, mais avec Vulkan.
	*   - Cr�e une fen�tre de taille `WIDTH` x `HEIGHT` avec le titre "Vulkan" en utilisant `glfwCreateWindow`.
	*     - Les param�tres `nullptr` pour le moniteur et le partage de contexte indiquent que la fen�tre sera cr��e en mode fen�tre (non plein �cran) et sans partage de contexte OpenGL.
	* - **Configuration des callbacks** :
	*   - D�finit le pointeur utilisateur de la fen�tre (`glfwSetWindowUserPointer`) � `this` (l'instance actuelle de `WindowPlatform`). Cela permet de r�cup�rer l'instance de `WindowPlatform` dans les callbacks GLFW.
	*   - D�finit le callback de redimensionnement du framebuffer (`glfwSetFramebufferSizeCallback`) � `FrameBufferResizeCallback`. Ce callback sera appel� chaque fois que la taille du framebuffer de la fen�tre change.
	*/
	void InitWindow(int _Width, int _Height, std::string _Name);

	/**
	* Nettoie les ressources de la fen�tre GLFW.
	*
	* @details
	* - **Destruction de la fen�tre** : Appelle `glfwDestroyWindow` pour d�truire la fen�tre GLFW (`m_Window`).
	* - **Terminaison de GLFW** : Appelle `glfwTerminate()` pour lib�rer toutes les ressources allou�es par GLFW.
	* - Cette m�thode est appel�e dans le destructeur pour garantir que les ressources sont lib�r�es lorsque l'objet `WindowPlatform` est d�truit.
	*
	* @note
	* - Apr�s l'appel � `Cleanup`, `m_Window` devient invalide. Toute tentative d'utiliser `m_Window` apr�s cela entra�nera un comportement ind�fini.
	* - Si `m_Window` est d�j� `nullptr`, `glfwDestroyWindow` ne fera rien.
	*/
	void Cleanup();

	void CreateWindowSurface(VkInstance _Instance, VkSurfaceKHR* Surface);

private:

	GLFWwindow* m_Window;

	int m_Width = WIDTH;
	int m_Height = HEIGHT;
	bool m_FramebufferResized = false;

	/**
	* Callback appel� lorsque la taille du framebuffer de la fen�tre change.
	* @param _Window Pointeur vers la fen�tre GLFW dont le framebuffer a �t� redimensionn�.
	* @param _Width Nouvelle largeur du framebuffer.
	* @param _Heigth Nouvelle hauteur du framebuffer.
	*
	* @details
	* - **R�cup�ration de l'instance de WindowPlatform** :
	*   - Utilise `glfwGetWindowUserPointer` pour r�cup�rer le pointeur utilisateur de la fen�tre (`this`), qui a �t� d�fini dans `InitWindow`.
	*   - Le pointeur est cast� en `WindowPlatform*` avec `reinterpret_cast`.
	* - **Notification � VulkanPlatform** :
	*   - Si `app->m_VulkanPlatform` n'est pas `nullptr`, appelle `SetFrameBufferResized(true)` sur la plateforme Vulkan associ�e.
	*   - Cela permet de notifier la plateforme Vulkan que le framebuffer a �t� redimensionn�, afin qu'elle puisse recr�er les ressources n�cessaires (comme le swap chain).
	*/
	static void FrameBufferResizeCallback(GLFWwindow* _Window, int _Width, int _Height);
};