#include "VulkanPlatform.h"
#include "WindowPlatform.h"

#include "../GameplayConcepts/Scene.h"

#include "../Core/GlobalFunctionLibrary.h"
#include "../Common/Error.h"

#include <set>
#include <unordered_set>


VulkanPlatform::VulkanPlatform()
{
}

VulkanPlatform::~VulkanPlatform()
{
	Cleanup();
}

void VulkanPlatform::InitVulkan(WindowPlatform* _WindowPlatform)
{ 
    m_VulkanInstance = std::make_unique<VulkanInstance>();
    m_VulkanInstance->Initialize();

	_WindowPlatform->CreateWindowSurface(m_VulkanInstance->GetInstance(), &m_VulkanData.Surface);

    m_VulkanDevice = std::make_unique<VulkanDevice>();
    m_VulkanDevice->Initialize(*m_VulkanInstance, m_VulkanData.Surface);

    m_VulkanSwapchain = std::make_unique<VulkanSwapchain>();
    m_VulkanSwapchain->Initialize(*m_VulkanDevice, m_VulkanData.Surface, _WindowPlatform->GetWindow());

	m_VulkanRenderer = std::make_unique<VulkanRenderer>();
	m_VulkanRenderer->Initialize(*m_VulkanDevice, *m_VulkanSwapchain);
    //m_VulkanPipeline = std::make_unique<VulkanGraphicsPipeline>();
    //m_VulkanPipeline->Initialize(*m_VulkanDevice, *m_VulkanSwapchain);

    m_CommandManager = std::make_unique<VulkanCommandManager>();
    m_CommandManager->Initialize(*m_VulkanDevice, GlobalFunctionLibrary::GetConfig()->MaxFramesInFlight);

    m_BufferManager = std::make_unique<VulkanBufferManager>();
    m_BufferManager->Initialize(*m_VulkanDevice, *m_CommandManager);

    //m_TextureManager = std::make_unique<TextureManager>();
    //m_TextureManager->Initialize(*m_VulkanDevice, *m_CommandManager, *m_BufferManager);

    //m_DescriptorManager = std::make_unique<DescriptorManager>();
    //m_DescriptorManager->Initialize(*m_VulkanDevice);

    CreateSyncObjects();
    CreateDepthResources();
    CreateFramebuffers();
}

void VulkanPlatform::DrawFrame(CameraBase* _Camera, float _DeltaTime)
{
    vkWaitForFences(m_VulkanDevice->GetLogicalDevice(), 1, &m_VulkanData.InFlightFences[m_VulkanData.CurrentFrameIndexInFlight], VK_TRUE, UINT64_MAX);
	
	m_CommandManager->ResetCommandBuffer(m_VulkanData.CurrentFrameIndexInFlight);

    VulkanFrameInfo frameInfo{};
    frameInfo.FrameIndex = 0;
    frameInfo.CurrentFrameIndexInFlight = m_VulkanData.CurrentFrameIndexInFlight;
    frameInfo.Camera = _Camera;
    frameInfo.FrameTime = _DeltaTime;
    frameInfo.CommandBuffer = m_CommandManager->GetCommandBuffer(m_VulkanData.CurrentFrameIndexInFlight);

    VkSemaphore imageAvailableSemaphore = m_VulkanData.ImageAvailableSemaphores[m_VulkanData.CurrentFrameIndexInFlight];
    VkResult acquireNextImageResult = vkAcquireNextImageKHR(m_VulkanDevice->GetLogicalDevice(), m_VulkanSwapchain->GetSwapchain(), UINT64_MAX, imageAvailableSemaphore, VK_NULL_HANDLE, &frameInfo.FrameIndex);
    
    if (acquireNextImageResult == VK_ERROR_OUT_OF_DATE_KHR) 
    {
        RecreateSwapchain();
        return;
    }
    else if (acquireNextImageResult != VK_SUCCESS && acquireNextImageResult != VK_SUBOPTIMAL_KHR) 
    {
        throw std::runtime_error("failed to acquire swap chain image!");
    }

    vkResetFences(m_VulkanDevice->GetLogicalDevice(), 1, &m_VulkanData.InFlightFences[m_VulkanData.CurrentFrameIndexInFlight]);

	GlobalFunctionLibrary::GetCurrentScene()->UpdateDraw(frameInfo);

    // Start GUI frame if enabled
    /*/if (GlobalFunctionLibrary::GetConfig()->enableGui && guiManager_) {
        guiManager_->newFrame();
        renderGui();  // Call derived class GUI rendering
    }*/

    // Record command buffer - delegate to derived class

    vkCmdEndRenderPass(frameInfo.CommandBuffer);
    VkResult endCommandBufferResult = vkEndCommandBuffer(frameInfo.CommandBuffer);
    if (endCommandBufferResult != VK_SUCCESS)
    {
        throw std::runtime_error("Failed to end command buffer recording!");
    }    

    VkSemaphore waitSemaphores[] = { m_VulkanData.ImageAvailableSemaphores[m_VulkanData.CurrentFrameIndexInFlight] };
    VkPipelineStageFlags waitStages[] = { VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT };
    VkSemaphore signalSemaphores[] = { m_VulkanData.RenderFinishedSemaphores[m_VulkanData.CurrentFrameIndexInFlight] };
    VkCommandBuffer commandBuffer = m_CommandManager->GetCommandBuffer(m_VulkanData.CurrentFrameIndexInFlight);

    VkSubmitInfo submitInfo{};
    submitInfo.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;
    submitInfo.waitSemaphoreCount = 1;
    submitInfo.pWaitSemaphores = waitSemaphores;
    submitInfo.pWaitDstStageMask = waitStages;
    submitInfo.commandBufferCount = 1;
    submitInfo.pCommandBuffers = &commandBuffer;
    submitInfo.signalSemaphoreCount = 1;
    submitInfo.pSignalSemaphores = signalSemaphores;

    VkResult queueSubmitResult = vkQueueSubmit(m_VulkanDevice->GetGraphicsQueue(), 1, &submitInfo, m_VulkanData.InFlightFences[m_VulkanData.CurrentFrameIndexInFlight]);
    if (queueSubmitResult != VK_SUCCESS) 
    {
        std::cout << "failed to submit draw command buffer - " << queueSubmitResult << std::endl;
        throw std::runtime_error("failed to submit draw command buffer!");
    }
    else 
    {
        // std::cout << "Successfully submmited command buffer - " << queueSubmitResult << std::endl;
    }

    VkSwapchainKHR swapChains[] = { m_VulkanSwapchain->GetSwapchain() };

    VkPresentInfoKHR presentInfo{};
    presentInfo.sType = VK_STRUCTURE_TYPE_PRESENT_INFO_KHR;
    presentInfo.waitSemaphoreCount = 1;
    presentInfo.pWaitSemaphores = signalSemaphores;
    presentInfo.swapchainCount = 1;
    presentInfo.pSwapchains = swapChains;
    presentInfo.pImageIndices = &frameInfo.FrameIndex;
    presentInfo.pResults = nullptr;

    VkResult queuePresentResult = vkQueuePresentKHR(m_VulkanDevice->GetPresentQueue(), &presentInfo);
    if (queuePresentResult == VK_ERROR_OUT_OF_DATE_KHR || queuePresentResult == VK_SUBOPTIMAL_KHR || m_FramebufferResized) 
    {
        m_FramebufferResized = false;
        RecreateSwapchain();
    }
    else if (queuePresentResult != VK_SUCCESS) 
    {
        throw std::runtime_error("failed to present swap chain image!");
    }

    m_VulkanData.CurrentFrameIndexInFlight = (m_VulkanData.CurrentFrameIndexInFlight + 1) % GlobalFunctionLibrary::GetConfig()->MaxFramesInFlight;
}

void VulkanPlatform::WaitIdle()
{
    if (m_VulkanDevice && m_VulkanDevice->GetLogicalDevice())
    {
        vkDeviceWaitIdle(m_VulkanDevice->GetLogicalDevice());
    }
}

void VulkanPlatform::Cleanup()
{
    WaitIdle();

    for (auto framebuffer : m_SwapchainFramebuffers)
    {
        vkDestroyFramebuffer(m_VulkanDevice->GetLogicalDevice(), framebuffer, nullptr);
    }

    OnCleanup();

    for (size_t i = 0; i < GlobalFunctionLibrary::GetConfig()->MaxFramesInFlight; i++) 
    {
        if (m_VulkanDevice && m_VulkanDevice->GetLogicalDevice()) 
        {
            if (m_VulkanData.RenderFinishedSemaphores[i] != VK_NULL_HANDLE) 
            {
                vkDestroySemaphore(m_VulkanDevice->GetLogicalDevice(), m_VulkanData.RenderFinishedSemaphores[i], nullptr);
                m_VulkanData.RenderFinishedSemaphores[i] = VK_NULL_HANDLE;
            }
            if (m_VulkanData.ImageAvailableSemaphores[i] != VK_NULL_HANDLE) 
            {
                vkDestroySemaphore(m_VulkanDevice->GetLogicalDevice(), m_VulkanData.ImageAvailableSemaphores[i], nullptr);
                m_VulkanData.ImageAvailableSemaphores[i] = VK_NULL_HANDLE;
            }
            if (m_VulkanData.InFlightFences[i] != VK_NULL_HANDLE) 
            {
                vkDestroyFence(m_VulkanDevice->GetLogicalDevice(), m_VulkanData.InFlightFences[i], nullptr);
                m_VulkanData.InFlightFences[i] = VK_NULL_HANDLE;
            }
        }
    }
    m_VulkanData.ImageAvailableSemaphores.clear();
    m_VulkanData.RenderFinishedSemaphores.clear();
    m_VulkanData.InFlightFences.clear();

    if (m_VulkanSwapchain) 
    {
        m_VulkanSwapchain.reset();
    }
}

void VulkanPlatform::RecreateSwapchain()
{
    GLFWwindow*  window = GlobalFunctionLibrary::GetWindow();
    int width = 0, height = 0;
    glfwGetFramebufferSize(window, &width, &height);
    while (width == 0 || height == 0) 
    {
        glfwGetFramebufferSize(window, &width, &height);
        glfwWaitEvents();
    }

    WaitIdle();

    for (size_t i = 0; i < GlobalFunctionLibrary::GetConfig()->MaxFramesInFlight; i++)
    {
        if (m_VulkanDevice && m_VulkanDevice->GetLogicalDevice())
        {
            if (m_VulkanData.RenderFinishedSemaphores[i] != VK_NULL_HANDLE)
            {
                vkDestroySemaphore(m_VulkanDevice->GetLogicalDevice(), m_VulkanData.RenderFinishedSemaphores[i], nullptr);
                m_VulkanData.RenderFinishedSemaphores[i] = VK_NULL_HANDLE;
            }
            if (m_VulkanData.ImageAvailableSemaphores[i] != VK_NULL_HANDLE)
            {
                vkDestroySemaphore(m_VulkanDevice->GetLogicalDevice(), m_VulkanData.ImageAvailableSemaphores[i], nullptr);
                m_VulkanData.ImageAvailableSemaphores[i] = VK_NULL_HANDLE;
            }
            if (m_VulkanData.InFlightFences[i] != VK_NULL_HANDLE)
            {
                vkDestroyFence(m_VulkanDevice->GetLogicalDevice(), m_VulkanData.InFlightFences[i], nullptr);
                m_VulkanData.InFlightFences[i] = VK_NULL_HANDLE;
            }
        }
    }

    m_VulkanData.ImageAvailableSemaphores.clear();
    m_VulkanData.RenderFinishedSemaphores.clear();
	m_VulkanData.InFlightFences.clear();


    m_VulkanSwapchain->RecreateSwapchain(window);

    CreateSyncObjects();

    CreateFramebuffers();
}

void VulkanPlatform::CreateSyncObjects()
{
    m_VulkanData.ImageAvailableSemaphores.resize(GlobalFunctionLibrary::GetConfig()->MaxFramesInFlight);
    m_VulkanData.RenderFinishedSemaphores.resize(GlobalFunctionLibrary::GetConfig()->MaxFramesInFlight);
    m_VulkanData.InFlightFences.resize(GlobalFunctionLibrary::GetConfig()->MaxFramesInFlight);

    VkSemaphoreCreateInfo semaphoreInfo{};
    semaphoreInfo.sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO;

    VkFenceCreateInfo fenceInfo{};
    fenceInfo.sType = VK_STRUCTURE_TYPE_FENCE_CREATE_INFO;
    fenceInfo.flags = VK_FENCE_CREATE_SIGNALED_BIT;

    for (size_t i = 0; i < GlobalFunctionLibrary::GetConfig()->MaxFramesInFlight; i++)
    {
        if (vkCreateSemaphore(m_VulkanDevice->GetLogicalDevice(), &semaphoreInfo, nullptr, &m_VulkanData.ImageAvailableSemaphores[i]) != VK_SUCCESS ||
            vkCreateSemaphore(m_VulkanDevice->GetLogicalDevice(), &semaphoreInfo, nullptr, &m_VulkanData.RenderFinishedSemaphores[i]) != VK_SUCCESS ||
            vkCreateFence(m_VulkanDevice->GetLogicalDevice(), &fenceInfo, nullptr, &m_VulkanData.InFlightFences[i]) != VK_SUCCESS) 
        {
            throw std::runtime_error("failed to create synchronization objects for a frame!");
        }
    }

}

void VulkanPlatform::CreateDepthResources()
{
    if(m_VulkanData.DepthTexture == nullptr)
    {
        m_VulkanData.DepthTexture = new TextureVoid();
        m_VulkanData.DepthTexture->GenerateDepthResources();
	}
}

void VulkanPlatform::CreateFramebuffers()
{
    const std::vector<VkImageView>& swapChainImageViews = m_VulkanSwapchain->GetImageViews();
    m_SwapchainFramebuffers.resize(swapChainImageViews.size());

    for (size_t i = 0; i < swapChainImageViews.size(); i++) 
    {
        std::array<VkImageView, 2> attachments = 
        {
            swapChainImageViews[i],
            m_VulkanData.DepthTexture->GetTextureImageView()
        };

        VkFramebufferCreateInfo framebufferInfo{};
        framebufferInfo.sType = VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO;
        framebufferInfo.renderPass = m_VulkanRenderer->GetRenderPass();
        framebufferInfo.attachmentCount = static_cast<uint32_t>(attachments.size());
        framebufferInfo.pAttachments = attachments.data();
        framebufferInfo.width = m_VulkanSwapchain->GetExtent().width;
        framebufferInfo.height = m_VulkanSwapchain->GetExtent().height;
        framebufferInfo.layers = 1;

        VkResult result = vkCreateFramebuffer(m_VulkanDevice->GetLogicalDevice(), &framebufferInfo, nullptr, &m_SwapchainFramebuffers[i]);
        if (result != VK_SUCCESS) 
        {
            std::cout << "failed to create framebuffer - " << i << " - " << result << std::endl;
            throw std::runtime_error("failed to create framebuffer!");
        }
        else 
        {
            std::cout << "successfully created framebuffer - " << i << " - " << result << std::endl;
        }
    }
}



