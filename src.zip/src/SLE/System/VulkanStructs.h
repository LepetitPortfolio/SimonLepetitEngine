
#pragma once
#define GLFW_INCLUDE_VULKAN
#include <GLFW/glfw3.h>

#define GLFORCE_RADIANS
#include <glm/glm.hpp>
//#include <glm/gtc/matrix_transform.hpp>

#include "../Common/Vertex.h"
#include "../Graphics/Textures/TextureVoid.h"

#include <optional>
#include <string>
#include <vector>

struct Config 
{
	uint32_t WindowWidth = 1600;
	uint32_t WindowHeight = 900;
	std::string WindowTitle = "SLE";
	uint32_t MaxFramesInFlight = 2;
	bool EnableValidation = true;
	bool EnableGui = true;
	std::string FontPath = "";
	float FontSize = 16.0f;
};

/**
 * Stocke les indices des familles de files d'attente (queue families) pour le rendu et la pr�sentation.
 *
 * En Vulkan, une "queue family" est un ensemble de files d'attente qui partagent les m�mes capacit�s.
 * Par exemple, une famille peut supporter le rendu graphique, tandis qu'une autre peut supporter la pr�sentation � l'�cran.
 */
struct QueueFamilyIndices
{
public:
	/**
	 * Index de la famille de files d'attente qui supporte les op�rations graphiques (rendu).
	 * @details
	 * - `std::optional<uint32_t>` permet de repr�senter un index qui peut �tre absent (si aucune famille ne supporte le rendu graphique).
	 * - Utilis� pour les commandes de dessin (ex: `vkCmdDraw`).
	 */
	std::optional<uint32_t> GraphicsFamily;

	/**
	 * Index de la famille de files d'attente qui supporte la pr�sentation (affichage � l'�cran).
	 * @details
	 * - `std::optional<uint32_t>` permet de repr�senter un index qui peut �tre absent (si aucune famille ne supporte la pr�sentation).
	 * - Utilis� pour pr�senter les images rendues � la surface de l'�cran (ex: via `vkQueuePresentKHR`).
	 */
	std::optional<uint32_t> PresentFamily;

	/**
	* V�rifie si les indices des familles de files d'attente sont complets.
	* @return true si les deux indices (GraphicsFamily et PresentFamily) sont d�finis, false sinon.
	*
	* @details
	* - Utilise `has_value()` pour v�rifier si `GraphicsFamily` et `PresentFamily` contiennent une valeur.
	* - Une instance de `QueueFamilyIndices` est consid�r�e comme "compl�te" si elle a � la fois un index pour le rendu et un index pour la pr�sentation.
	*/
	bool IsComplete()
	{
		return GraphicsFamily.has_value() && PresentFamily.has_value();
	}
};

/**
 * Stocke les d�tails de support du swap chain pour une surface Vulkan.
 *
 * Ces d�tails sont utilis�s pour configurer le swap chain, qui est responsable de la pr�sentation des images rendues � l'�cran.
 */
struct SwapChainSupportDetails
{
public:
	/**
	 * Capacit�s de la surface (ex: taille minimale/maximale des images, nombre d'images, etc.).
	 * @details
	 * - `VkSurfaceCapabilitiesKHR` contient des informations comme :
	 *   - `minImageCount` : Nombre minimal d'images dans le swap chain.
	 *   - `maxImageCount` : Nombre maximal d'images dans le swap chain (0 = pas de limite).
	 *   - `currentExtent` : Taille actuelle de la surface (en pixels).
	 *   - `minImageExtent` / `maxImageExtent` : Tailles minimale et maximale des images.
	 *   - `supportedUsageFlags` : Utilisations support�es pour les images du swap chain (ex: `VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT`).
	 */
	VkSurfaceCapabilitiesKHR Capabilities;

	/**
	 * Liste des formats de surface support�s (ex: RGBA8, BGRA8, etc.).
	 * @details
	 * - `std::vector<VkSurfaceFormatKHR>` contient les formats disponibles pour les images du swap chain.
	 * - Chaque `VkSurfaceFormatKHR` contient :
	 *   - `format` : Format des pixels (ex: `VK_FORMAT_B8G8R8A8_SRGB`).
	 *   - `colorSpace` : Espace colorim�trique (ex: `VK_COLOR_SPACE_SRGB_NONLINEAR_KHR`).
	 */
	std::vector<VkSurfaceFormatKHR> Formats;

	/**
	 * Liste des modes de pr�sentation support�s (ex: FIFO, MAILBOX, etc.).
	 * @details
	 * - `std::vector<VkPresentModeKHR>` contient les modes de pr�sentation disponibles.
	 * - Exemples de modes :
	 *   - `VK_PRESENT_MODE_IMMEDIATE_KHR` : Pr�sentation imm�diate (peut causer des d�chirures).
	 *   - `VK_PRESENT_MODE_FIFO_KHR` : Pr�sentation en file d'attente (VSYNC, pas de d�chirure).
	 *   - `VK_PRESENT_MODE_MAILBOX_KHR` : Pr�sentation en mode "bo�te aux lettres" (triple buffering, pas de d�chirure).
	 *   - `VK_PRESENT_MODE_RELAXED_FIFO_KHR` : Similaire � FIFO, mais peut sauter des images si l'application est en retard.
	 */
	std::vector<VkPresentModeKHR> PresentModes;
};

/**
 * Stocke les matrices de transformation pour le rendu 3D.
 *
 * Les UBOs sont utilis�s pour passer des donn�es uniformes (comme les matrices de transformation) aux shaders.
 * L'alignement (`alignas`) est n�cessaire pour respecter les exigences d'alignement du GPU.
 */
struct UniformBufferObject
{
public:

	alignas(16) glm::mat4 Model;

	/**
	 * Matrice de projection (transformation de la vue 3D en 2D pour l'�cran).
	 * @details
	 * - `glm::mat4` repr�sente la projection (perspective ou orthographique).
	 * - `alignas(16)` garantit l'alignement sur 16 octets.
	 */
	alignas(16) glm::mat4 Projection;

	/**
	 * Matrice de vue (transformation de la cam�ra dans l'espace monde).
	 * @details
	 * - `glm::mat4` repr�sente la position et l'orientation de la cam�ra.
	 * - `alignas(16)` garantit l'alignement sur 16 octets.
	 */
	alignas(16) glm::mat4 View;

	alignas(16) glm::mat4 InverseView;	
};


struct VulkanData
{

public:
	// --------------------------------------------------------------------
	// Messager de d�bogage Vulkan (extension EXT) : permet de recevoir des notifications de validation,
	// d'erreurs ou d'avertissements de l'API Vulkan pendant le d�veloppement.
	VkDebugUtilsMessengerEXT DebugMessenger;

	// --------------------------------------------------------------------
	// Surface Vulkan : interface entre la fen�tre syst�me (ex: GLFW) et Vulkan.
	// Repr�sente la zone o� les images seront affich�es.
	VkSurfaceKHR Surface;


	// --------------------------------------------------------------------
	// Nombre d'�chantillons pour le multisampling (MSAA) : am�liore la qualit� visuelle en r�duisant les aliasing.
	// Initialis� � VK_SAMPLE_COUNT_1_BIT (pas de MSAA par d�faut).
	VkSampleCountFlagBits MSAASamples = VK_SAMPLE_COUNT_1_BIT;

	TextureVoid* DepthTexture = nullptr;

	std::vector<VkSemaphore> ImageAvailableSemaphores{};

	std::vector<VkSemaphore> RenderFinishedSemaphores{};

	std::vector<VkFence> InFlightFences{};

	uint32_t CurrentFrameIndexInFlight = 0;

	VulkanData() = default;

	//VulkanData(const VulkanData&) = delete;
	//VulkanData& operator=(const VulkanData&) = delete;
};

struct VulkanFrameInfo
{
public:
	uint32_t FrameIndex;
	uint32_t CurrentFrameIndexInFlight;
	float FrameTime;
	VkCommandBuffer CommandBuffer;
	class CameraBase* Camera;
};

struct PipelineConfigInfo 
{
public:
	std::vector<VkVertexInputBindingDescription> BindingDescriptions{};
	std::vector<VkVertexInputAttributeDescription> AttributeDescriptions{};
	VkPipelineViewportStateCreateInfo ViewportInfo;
	VkPipelineInputAssemblyStateCreateInfo InputAssemblyInfo;
	VkPipelineRasterizationStateCreateInfo RasterizationInfo;
	VkPipelineMultisampleStateCreateInfo MultisampleInfo;
	VkPipelineColorBlendAttachmentState ColorBlendAttachment;
	VkPipelineColorBlendStateCreateInfo ColorBlendInfo;
	VkPipelineDepthStencilStateCreateInfo DepthStencilInfo;
	std::vector<VkDynamicState> DynamicStateEnables;
	VkPipelineDynamicStateCreateInfo DynamicStateInfo;
	VkPipelineLayout PipelineLayout = nullptr;
	VkRenderPass RenderPass = nullptr;
	uint32_t Subpass = 0;

	PipelineConfigInfo() = default;
	//PipelineConfigInfo(const PipelineConfigInfo&) = delete;
	//PipelineConfigInfo& operator=(const PipelineConfigInfo&) = delete;
};