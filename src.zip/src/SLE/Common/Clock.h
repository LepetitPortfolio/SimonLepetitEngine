#pragma once

#include <chrono>
#include <ratio>
#include <type_traits>

using ClockType = std::conditional_t<std::chrono::high_resolution_clock::is_steady, std::chrono::high_resolution_clock, std::chrono::steady_clock>;

static_assert(ClockType::is_steady, "Provided implementation is not a monotonic clock");
static_assert(std::ratio_less_equal_v<ClockType::period, std::micro >, "Clock resolution is too low. Expecting at least a microsecond precision");


class Time;

class Clock
{
public:

	/**
	 * Relance le chronom�tre s'il est arr�t�.
	 *
	 * Si le chronom�tre n'est pas en cours d'ex�cution (IsRunning() == false) :
	 * - Ajoute � m_RefPoint la dur�e �coul�e entre l'arr�t (m_StopPoint) et maintenant (ClockType::now()).
	 *   Cela permet de reprendre la mesure du temps l� o� elle s'�tait arr�t�e.
	 * - R�initialise m_StopPoint � une valeur vide (time_point vide), indiquant que le chronom�tre est en cours.
	 */
	void Start();

	/**
	 * Arr�te le chronom�tre s'il est en cours.
	 *
	 * Si le chronom�tre est en cours d'ex�cution (IsRunning() == true) :
	 * - Enregistre l'heure actuelle (ClockType::now()) dans m_StopPoint pour marquer l'arr�t.
	 */
	void Stop();

	/**
	* @fn Time Clock::Restart()
	* @brief Red�marre le chronom�tre et retourne le temps �coul� depuis le dernier d�marrage.
	*
	* - R�cup�re le temps �coul� actuel (GetElapsedTime()) avant de red�marrer.
	* - R�initialise m_RefPoint � l'heure actuelle (ClockType::now()) pour commencer une nouvelle mesure.
	* - R�initialise m_StopPoint � une valeur vide (time_point vide).
	* - @return Le temps �coul� (en microsecondes) depuis le dernier d�marrage.
	*/
	Time Restart();

	/**
	* R�initialise le chronom�tre et retourne le temps �coul� depuis le dernier d�marrage.
	*
	* - R�cup�re le temps �coul� actuel (GetElapsedTime()) avant la r�initialisation.
	* - R�initialise m_RefPoint � l'heure actuelle (ClockType::now()).
	* - D�finit m_StopPoint � m_RefPoint, ce qui force IsRunning() � retourner false (car m_StopPoint != time_point vide).
	* - @return Le temps �coul� (en microsecondes) depuis le dernier d�marrage.
	*/
	Time Reset();

	/**
	* V�rifie si le chronom�tre est en cours d'ex�cution.
	*
	* - @return true si m_StopPoint est vide (time_point vide), ce qui signifie que le chronom�tre est actif.
	* - @return false si m_StopPoint contient une valeur, indiquant que le chronom�tre est arr�t�.
	*/
	bool IsRunning() const;

	/**
	* @fn Time Clock::GetElapsedTime() const
	* @brief Calcule et retourne le temps �coul� depuis le dernier d�marrage (en microsecondes).
	*
	* - Si le chronom�tre est en cours (IsRunning() == true) :
	*   - Retourne la dur�e entre l'heure actuelle (ClockType::now()) et m_RefPoint.
	* - Si le chronom�tre est arr�t� (IsRunning() == false) :
	*   - Retourne la dur�e entre m_StopPoint et m_RefPoint.
	* - @return Le temps �coul� en microsecondes (std::chrono::microseconds).
	*/
	Time GetElapsedTime() const;

private:

	/**
	 * Point de r�f�rence pour le d�but de la mesure du temps.
	 * Initialis� � l'heure actuelle (ClockType::now()) lors de la construction.
	 * Repr�sente le moment � partir duquel le temps �coul� est calcul�.
	 */
	ClockType::time_point m_RefPoint{ ClockType::now() };

	/**
	 * Point d'arr�t temporaire du chronom�tre.
	 * - Si vide (time_point vide), le chronom�tre est en cours d'ex�cution (IsRunning() == true).
	 * - Si non vide, contient l'heure � laquelle le chronom�tre a �t� arr�t� (Stop() appel�).
	 */
	ClockType::time_point m_StopPoint;

};