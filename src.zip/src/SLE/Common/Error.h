#pragma once

#include <iosfwd>
#include <iostream>
#include <streambuf>

#include <cstdio>

std::ostream& Log();

std::ostream& Warning();


/**
 * Fournit un flux de sortie (std::ostream) pour �crire des messages d'erreur.
 *
 * @return R�f�rence vers un flux std::ostream statique, li� au tampon `DefaultErrorStreamBuf`.
 *
 * @details
 * - Utilise un tampon (`DefaultErrorStreamBuf`) et un flux (`std::ostream`) statiques pour �viter les r�allocations.
 * - Le flux est initialis� avec l'adresse du tampon, ce qui permet d'�crire des messages d'erreur via ce flux.
 * - Exemple d'utilisation : `Err() << "Erreur : " << message;`
 */
std::ostream& Err();

std::ostream& FatalErr();

class DefaultErrorStreamBuf : public std::streambuf
{
public:

	/**
	* Constructeur : initialise un tampon de taille fixe pour stocker les caract�res.
	*
	* - Alloue dynamiquement un tableau de caract�res de taille 64.
	* - Configure le tampon de sortie (output buffer) avec `setp` :
	*   - `buffer` : d�but du tampon.
	*   - `buffer + size` : fin du tampon.
	*   Cela permet � std::ostream d'�crire dans ce tampon avant de le vider.
	*/
	DefaultErrorStreamBuf();

	/**
	* Destructeur : lib�re les ressources allou�es.
	*
	* - Appelle `sync()` pour vider le tampon avant la destruction (�crit les donn�es restantes dans stderr).
	* - Lib�re la m�moire allou�e pour le tampon via `delete[] pbase()`.
	*   `pbase()` retourne le pointeur vers le d�but du tampon de sortie.
	*/
	~DefaultErrorStreamBuf() override;

private:

	/**
	* G�re le d�bordement du tampon (quand le tampon est plein ou qu'un caract�re EOF est rencontr�).
	*
	* @param _Character Caract�re � �crire ou EOF (fin de flux).
	* @return EOF en cas d'erreur, sinon le caract�re �crit ou un code de succ�s.
	*
	* @details
	* - Si `_Character` n'est pas EOF et qu'il reste de la place dans le tampon (`pptr() != epptr()`) :
	*   - �crit le caract�re dans le tampon via `sputc` et retourne le r�sultat.
	* - Si `_Character` est EOF :
	*   - Appelle `sync()` pour vider le tampon, puis rappelle `overflow(_Character)`.
	* - Si le tampon est plein et que `_Character` n'est pas EOF :
	*   - Appelle `sync()` pour vider le tampon et lib�rer de l'espace.
	*/
	int overflow(int _Character) override;

	/**
	* Vide le tampon en �crivant son contenu dans stderr (flux d'erreur standard).
	*
	* @return 0 en cas de succ�s, ou un code d'erreur sinon.
	*
	* @details
	* - Si le tampon contient des donn�es (`pbase() != pptr()`) :
	*   - Calcule la taille des donn�es � �crire (`pptr() - pbase()`).
	*   - �crit les donn�es dans `stderr` via `std::fwrite`.
	*   - R�initialise le pointeur de position du tampon (`pptr`) au d�but (`pbase`) pour permettre de nouvelles �critures.
	*/
	int sync() override;
};