#pragma once

#include <array>
#include <locale>

#include <cstdint>
#include <cstdlib>

class UTF
{
public:

	/**
	* D�code un point de code UTF-8 � partir d'un it�rateur.
	* @tparam T Type de l'it�rateur (doit pointer vers des `char` ou `uint8_t`).
	* @param _Begin It�rateur de d�but.
	* @param _End It�rateur de fin.
	* @param _Output R�f�rence vers le point de code d�cod� (sortie).
	* @param _Replacement Point de code de remplacement en cas d'erreur.
	* @return It�rateur pointant apr�s le dernier octet du point de code d�cod�.
	*
	* @details
	* - Utilise un tableau `trailing` pour d�terminer le nombre d'octets de continuation en fonction du premier octet.
	* - Utilise un tableau `offsets` pour ajuster le point de code final.
	* - Si le nombre d'octets de continuation est suffisant, d�code le point de code en combinant les octets.
	* - Si le premier octet est invalide ou s'il n'y a pas assez d'octets de continuation, utilise `_Replacement`.
	*
	* @note
	* Les octets de continuation en UTF-8 commencent par `10xxxxxx`.
	* Le premier octet indique le nombre d'octets de continuation (ex: `110xxxxx` = 1 octet de continuation).
	*/
	template<typename T>
	static T Decode(T _Begin, T _End, char32_t& _Output, char32_t _Replacement = 0);

	/**
	* Avance l'it�rateur vers le prochain point de code UTF (caract�re suivant).
	* @tparam T Type de l'it�rateur.
	* @param _Begin It�rateur de d�but.
	* @param _End It�rateur de fin.
	* @return It�rateur pointant vers le d�but du prochain point de code.
	*
	* @details
	* Utilise `Decode` pour lire un point de code UTF et avance l'it�rateur en cons�quence.
	* Le point de code lu est ignor� (non stock�).
	*/
	template<typename T>
	static T Next(T _Begin, T _End);

	/**
	* Compte le nombre de points de code UTF dans une plage.
	* @tparam T Type de l'it�rateur.
	* @param _Begin It�rateur de d�but.
	* @param _End It�rateur de fin.
	* @return Nombre de points de code dans la plage.
	*
	* @details
	* Parcourt la plage en appelant `Next` jusqu'� atteindre la fin, en incr�mentant un compteur � chaque it�ration.
	*/
	template<typename T>
	static std::size_t Count(T _Begin, T _End);

	/**
	* Convertit une cha�ne ANSI en UTF-32.
	* @tparam In Type de l'it�rateur d'entr�e (ANSI).
	* @tparam Out Type de l'it�rateur de sortie (UTF-32).
	* @param _Begin It�rateur de d�but de la cha�ne ANSI.
	* @param _End It�rateur de fin de la cha�ne ANSI.
	* @param _Output It�rateur de sortie pour la cha�ne UTF-32.
	* @param _Locale Locale utilis�e pour la conversion.
	* @return It�rateur de sortie pointant apr�s le dernier caract�re �crit.
	*
	* @details
	* Pour chaque caract�re ANSI, utilise `UTF32::DecodeANSI` pour le convertir en UTF-32,
	* puis `Encode` pour l'�crire dans la sortie.
	*/
	template<typename In, typename Out>
	static Out FromANSI(In _Begin, In _End, Out _Output, std::locale& _Locale = {});

	/**
	* Convertit une cha�ne WIDE (wchar_t) en UTF-32.
	* @tparam In Type de l'it�rateur d'entr�e (WIDE).
	* @tparam Out Type de l'it�rateur de sortie (UTF-32).
	* @param _Begin It�rateur de d�but de la cha�ne WIDE.
	* @param _End It�rateur de fin de la cha�ne WIDE.
	* @param _Output It�rateur de sortie pour la cha�ne UTF-32.
	* @return It�rateur de sortie pointant apr�s le dernier caract�re �crit.
	*
	* @details
	* Pour chaque caract�re WIDE, utilise `UTF32::DecodeWIDE` pour le convertir en UTF-32,
	* puis `Encode` pour l'�crire dans la sortie.
	*/
	template<typename In, typename Out>
	static Out FromWIDE(In _Begin, In _End, Out _Output);

	/**
	* Convertit une cha�ne LATIN1 en UTF-32.
	* @tparam In Type de l'it�rateur d'entr�e (LATIN1).
	* @tparam Out Type de l'it�rateur de sortie (UTF-32).
	* @param _Begin It�rateur de d�but de la cha�ne LATIN1.
	* @param _End It�rateur de fin de la cha�ne LATIN1.
	* @param _Output It�rateur de sortie pour la cha�ne UTF-32.
	* @return It�rateur de sortie pointant apr�s le dernier caract�re �crit.
	*
	* @details
	* LATIN1 est un encodage 1:1 avec les 256 premiers points de code Unicode.
	* Utilise `Copy` pour copier directement les octets (pas de conversion n�cessaire).
	*/
	template<typename In, typename Out>
	static Out FromLATIN1(In _Begin, In _End, Out _Output);

	/**
	* Convertit une cha�ne UTF-32 en ANSI.
	* @tparam In Type de l'it�rateur d'entr�e (UTF-32).
	* @tparam Out Type de l'it�rateur de sortie (ANSI).
	* @param _Begin It�rateur de d�but de la cha�ne UTF-32.
	* @param _End It�rateur de fin de la cha�ne UTF-32.
	* @param _Output It�rateur de sortie pour la cha�ne ANSI.
	* @param _Replacement Caract�re de remplacement en cas d'erreur.
	* @param _Locale Locale utilis�e pour la conversion.
	* @return It�rateur de sortie pointant apr�s le dernier caract�re �crit.
	*
	* @details
	* Pour chaque point de code UTF-32, utilise `Decode` pour le lire,
	* puis `UTF32::EncodeANSI` pour le convertir en ANSI.
	*/
	template<typename In, typename Out>
	static Out ToANSI(In _Begin, In _End, Out _Output, char _Replacement = 0, std::locale& _Locale = {});

	/**
	* Convertit une cha�ne UTF-32 en WIDE (wchar_t).
	* @tparam In Type de l'it�rateur d'entr�e (UTF-32).
	* @tparam Out Type de l'it�rateur de sortie (WIDE).
	* @param _Begin It�rateur de d�but de la cha�ne UTF-32.
	* @param _End It�rateur de fin de la cha�ne UTF-32.
	* @param _Output It�rateur de sortie pour la cha�ne WIDE.
	* @param _Replacement Caract�re de remplacement en cas d'erreur.
	* @return It�rateur de sortie pointant apr�s le dernier caract�re �crit.
	*
	* @details
	* Pour chaque point de code UTF-32, utilise `Decode` pour le lire,
	* puis `UTF32::EncodeWIDE` pour le convertir en WIDE.
	*/
	template<typename In, typename Out>
	static Out ToWIDE(In _Begin, In _End, Out _Output, wchar_t _Replacement = 0);

	/**
	* Convertit une cha�ne UTF-32 en LATIN1.
	* @tparam In Type de l'it�rateur d'entr�e (UTF-32).
	* @tparam Out Type de l'it�rateur de sortie (LATIN1).
	* @param _Begin It�rateur de d�but de la cha�ne UTF-32.
	* @param _End It�rateur de fin de la cha�ne UTF-32.
	* @param _Output It�rateur de sortie pour la cha�ne LATIN1.
	* @param _Replacement Caract�re de remplacement si le point de code > 255.
	* @return It�rateur de sortie pointant apr�s le dernier caract�re �crit.
	*
	* @details
	* Pour chaque point de code UTF-32, v�rifie s'il est dans la plage LATIN1 (0-255).
	* Si oui, le copie tel quel, sinon utilise `_Replacement`.
	*/
	template<typename In, typename Out>
	static Out ToLATIN1(In _Begin, In _End, Out _Output, char _Replacement = 0);

	/**
	* Convertit une cha�ne UTF-32 en UTF-8.
	* @tparam In Type de l'it�rateur d'entr�e (UTF-32).
	* @tparam Out Type de l'it�rateur de sortie (UTF-8).
	* @param _Begin It�rateur de d�but de la cha�ne UTF-32.
	* @param _End It�rateur de fin de la cha�ne UTF-32.
	* @param _Output It�rateur de sortie pour la cha�ne UTF-8.
	* @return It�rateur de sortie pointant apr�s le dernier caract�re �crit.
	*
	* @details
	* Utilise `Copy` car UTF-32 et UTF-8 sont tous deux des encodages Unicode.
	*/
	template<typename In, typename Out>
	static Out ToUTF8(In _Begin, In _End, Out _Output);

	/**
	* Convertit une cha�ne UTF-32 en UTF-16.
	* @tparam In Type de l'it�rateur d'entr�e (UTF-32).
	* @tparam Out Type de l'it�rateur de sortie (UTF-16).
	* @param _Begin It�rateur de d�but de la cha�ne UTF-32.
	* @param _End It�rateur de fin de la cha�ne UTF-32.
	* @param _Output It�rateur de sortie pour la cha�ne UTF-16.
	* @return It�rateur de sortie pointant apr�s le dernier caract�re �crit.
	*/
	template<typename In, typename Out>
	static Out ToUTF16(In _Begin, In _End, Out _Output);

	/**
	* Convertit une cha�ne UTF-32 en UTF-32 (copie directe).
	* @tparam In Type de l'it�rateur d'entr�e (UTF-32).
	* @tparam Out Type de l'it�rateur de sortie (UTF-32).
	* @param _Begin It�rateur de d�but de la cha�ne UTF-32.
	* @param _End It�rateur de fin de la cha�ne UTF-32.
	* @param _Output It�rateur de sortie pour la cha�ne UTF-32.
	* @return It�rateur de sortie pointant apr�s le dernier caract�re �crit.
	*/
	template<typename In, typename Out>
	static Out ToUTF32(In _Begin, In _End, Out _Output);

protected:

	/**
	* Copie une plage de caract�res d'un it�rateur d'entr�e vers un it�rateur de sortie.
	* @tparam InIt Type de l'it�rateur d'entr�e.
	* @tparam OutIt Type de l'it�rateur de sortie.
	* @param _First It�rateur de d�but de la plage d'entr�e.
	* @param _Last It�rateur de fin de la plage d'entr�e.
	* @param _Ouput It�rateur de sortie o� copier les caract�res.
	* @return It�rateur de sortie pointant apr�s le dernier caract�re copi�.
	*
	* @details
	* Copie chaque caract�re de la plage [_First, _Last) vers _Ouput en les castant vers le type de valeur du conteneur de sortie.
	*/
	template<typename InIt, typename OutIt>
	static OutIt Copy(InIt _First, InIt _Last, OutIt _Ouput);

};

class UTF8 : public UTF
{
public:


	/**
	* D�code un point de code UTF-8 � partir d'un it�rateur.
	* @tparam T Type de l'it�rateur (doit pointer vers des `char` ou `uint8_t`).
	* @param _Begin It�rateur de d�but.
	* @param _End It�rateur de fin.
	* @param _Output R�f�rence vers le point de code d�cod� (sortie).
	* @param _Replacement Point de code de remplacement en cas d'erreur.
	* @return It�rateur pointant apr�s le dernier octet du point de code d�cod�.
	*
	* @details
	* - Utilise un tableau `trailing` pour d�terminer le nombre d'octets de continuation en fonction du premier octet.
	* - Utilise un tableau `offsets` pour ajuster le point de code final.
	* - Si le nombre d'octets de continuation est suffisant, d�code le point de code en combinant les octets.
	* - Si le premier octet est invalide ou s'il n'y a pas assez d'octets de continuation, utilise `_Replacement`.
	*
	* @note
	* Les octets de continuation en UTF-8 commencent par `10xxxxxx`.
	* Le premier octet indique le nombre d'octets de continuation (ex: `110xxxxx` = 1 octet de continuation).
	*/
	template<typename T>
	static T Decode(T _Begin, T _End, char32_t& _Output, char32_t _Replacement = 0);

	/**
	* Encode un point de code UTF-32 en UTF-8.
	* @tparam T Type de l'it�rateur de sortie.
	* @param _Input Point de code UTF-32 � encoder.
	* @param _Output It�rateur de sortie pour la cha�ne UTF-8.
	* @param _Replacement Octet de remplacement en cas d'erreur.
	* @return It�rateur de sortie pointant apr�s le dernier octet �crit.
	*
	* @details
	* - V�rifie si `_Input` est un point de code valide (0x0000 � 0x10FFFF, hors plage des surrogates 0xD800-0xDFFF).
	* - D�termine le nombre d'octets n�cessaires pour encoder le point de code :
	*   - 1 octet : 0x0000-0x007F
	*   - 2 octets : 0x0080-0x07FF
	*   - 3 octets : 0x0800-0xFFFF
	*   - 4 octets : 0x10000-0x10FFFF
	* - Utilise un tableau `firstBytes` pour d�terminer le premier octet de la s�quence UTF-8.
	* - Extrait les bits du point de code et les r�partit dans les octets de sortie.
	*
	* @note
	* Les octets de continuation en UTF-8 commencent par `10xxxxxx`.
	* Le premier octet commence par `110xxxxx` (2 octets), `1110xxxx` (3 octets), ou `11110xxx` (4 octets).
	*/
	template<typename T>
	static T Encode(char32_t _Input, T _Output, std::uint8_t _Replacement = 0);

	/**
	* Convertit une cha�ne LATIN1 en UTF-8.
	* @tparam In Type de l'it�rateur d'entr�e (LATIN1).
	* @tparam Out Type de l'it�rateur de sortie (UTF-8).
	* @param _Begin It�rateur de d�but de la cha�ne LATIN1.
	* @param _End It�rateur de fin de la cha�ne LATIN1.
	* @param _Output It�rateur de sortie pour la cha�ne UTF-8.
	* @return It�rateur de sortie pointant apr�s le dernier octet �crit.
	*
	* @details
	* LATIN1 est un encodage 1:1 avec les 256 premiers points de code Unicode.
	* Chaque caract�re LATIN1 est encod� en UTF-8 (1 ou 2 octets).
	*/
	template<typename In, typename Out>
	static Out FromLATIN1(In _Begin, In _End, Out _Output);

	/**
	* Convertit une cha�ne UTF-8 en LATIN1.
	* @tparam In Type de l'it�rateur d'entr�e (UTF-8).
	* @tparam Out Type de l'it�rateur de sortie (LATIN1).
	* @param _Begin It�rateur de d�but de la cha�ne UTF-8.
	* @param _End It�rateur de fin de la cha�ne UTF-8.
	* @param _Output It�rateur de sortie pour la cha�ne LATIN1.
	* @param _Replacement Caract�re de remplacement si le point de code > 255.
	* @return It�rateur de sortie pointant apr�s le dernier caract�re �crit.
	*
	* @details
	* D�code chaque point de code UTF-8 et v�rifie s'il est dans la plage LATIN1 (0-255).
	* Si oui, le copie tel quel, sinon utilise `_Replacement`.
	*/
	template<typename In, typename Out>
	static Out ToLATIN1(In _Begin, In _End, Out _Output, char _Replacement = 0);

	/**
	* Convertit une cha�ne UTF-8 en UTF-16.
	* @tparam In Type de l'it�rateur d'entr�e (UTF-8).
	* @tparam Out Type de l'it�rateur de sortie (UTF-16).
	* @param _Begin It�rateur de d�but de la cha�ne UTF-8.
	* @param _End It�rateur de fin de la cha�ne UTF-8.
	* @param _Output It�rateur de sortie pour la cha�ne UTF-16.
	* @return It�rateur de sortie pointant apr�s le dernier caract�re �crit.
	*
	* @details
	* D�code chaque point de code UTF-8, puis l'encode en UTF-16.
	*/
	template<typename In, typename Out>
	static Out ToUTF16(In _Begin, In _End, Out _Output);

	/**
	* Convertit une cha�ne UTF-8 en UTF-32.
	* @tparam In Type de l'it�rateur d'entr�e (UTF-8).
	* @tparam Out Type de l'it�rateur de sortie (UTF-32).
	* @param _Begin It�rateur de d�but de la cha�ne UTF-8.
	* @param _End It�rateur de fin de la cha�ne UTF-8.
	* @param _Output It�rateur de sortie pour la cha�ne UTF-32.
	* @return It�rateur de sortie pointant apr�s le dernier caract�re �crit.
	*
	* @details
	* D�code chaque point de code UTF-8 et l'�crit directement en UTF-32 (1:1).
	*/
	template<typename In, typename Out>
	static Out ToUTF32(In _Begin, In _End, Out _Output);
};

class UTF16 : public UTF
{
public:

	/**
	* D�code un point de code UTF-16 � partir d'un it�rateur.
	* @tparam T Type de l'it�rateur (doit pointer vers des `char16_t`).
	* @param _Begin It�rateur de d�but.
	* @param _End It�rateur de fin.
	* @param _Output R�f�rence vers le point de code d�cod� (sortie).
	* @param _Replacement Point de code de remplacement en cas d'erreur.
	* @return It�rateur pointant apr�s le dernier octet du point de code d�cod�.
	*
	* @details
	* - UTF-16 utilise des **paires de surrogates** pour repr�senter les points de code > 0xFFFF.
	* - Si le premier caract�re est un **surrogate haut** (0xD800-0xDBFF), v�rifie s'il est suivi d'un **surrogate bas** (0xDC00-0xDFFF).
	* - Si les deux surrogates sont valides, combine-les pour former le point de code final.
	* - Sinon, utilise `_Replacement`.
	*/
	template<typename T>
	static T Decode(T _Begin, T _End, char32_t& _Output, char32_t _Replacement = 0);

	/**
	* Encode un point de code UTF-32 en UTF-16.
	* @tparam T Type de l'it�rateur de sortie.
	* @param _Input Point de code UTF-32 � encoder.
	* @param _Output It�rateur de sortie pour la cha�ne UTF-16.
	* @param _Replacement Caract�re de remplacement en cas d'erreur.
	* @return It�rateur de sortie pointant apr�s le dernier caract�re �crit.
	*
	* @details
	* - Si `_Input` est dans la **plage des surrogates** (0xD800-0xDFFF), utilise `_Replacement`.
	* - Si `_Input` est > 0x10FFFF, utilise `_Replacement`.
	* - Si `_Input` est <= 0xFFFF, l'�crit directement.
	* - Sinon, d�compose `_Input` en une **paire de surrogates** (haut + bas).
	*/
	template<typename T>
	static T Encode(char32_t _Input, T _Output, std::uint16_t _Replacement = 0);

	/**
	* Convertit une cha�ne UTF-16 en UTF-8.
	* @tparam In Type de l'it�rateur d'entr�e (UTF-16).
	* @tparam Out Type de l'it�rateur de sortie (UTF-8).
	* @param _Begin It�rateur de d�but de la cha�ne UTF-16.
	* @param _End It�rateur de fin de la cha�ne UTF-16.
	* @param _Output It�rateur de sortie pour la cha�ne UTF-8.
	* @return It�rateur de sortie pointant apr�s le dernier octet �crit.
	*
	* @details
	* D�code chaque point de code UTF-16, puis l'encode en UTF-8.
	*/
	template<typename In, typename Out>
	static Out ToUTF8(In _Begin, In _End, Out _Output);

	/**
	* Convertit une cha�ne UTF-16 en UTF-32.
	* @tparam In Type de l'it�rateur d'entr�e (UTF-16).
	* @tparam Out Type de l'it�rateur de sortie (UTF-32).
	* @param _Begin It�rateur de d�but de la cha�ne UTF-16.
	* @param _End It�rateur de fin de la cha�ne UTF-16.
	* @param _Output It�rateur de sortie pour la cha�ne UTF-32.
	* @return It�rateur de sortie pointant apr�s le dernier caract�re �crit.
	*
	* @details
	* D�code chaque point de code UTF-16 et l'�crit directement en UTF-32 (1:1).
	*/
	template<typename In, typename Out>
	static Out ToUTF32(In _Begin, In _End, Out _Output);
};

class UTF32 : public UTF
{
public:

	/**
	* D�code un point de code UTF-32 � partir d'un it�rateur.
	* @tparam T Type de l'it�rateur (doit pointer vers des `char32_t`).
	* @param _Begin It�rateur de d�but.
	* @param _End It�rateur de fin.
	* @param _Output R�f�rence vers le point de code d�cod� (sortie).
	* @param _Replacement Point de code de remplacement (non utilis� ici).
	* @return It�rateur pointant apr�s le point de code d�cod�.
	*
	* @details
	* UTF-32 est un encodage 1:1 : chaque point de code est stock� sur 4 octets.
	* Cette fonction se contente de lire le point de code et d'avancer l'it�rateur.
	*/
	template<typename T>
	static T Decode(T _Begin, T _End, char32_t& _Output, char32_t _Replacement = 0);

	/**
	* Encode un point de code UTF-32.
	* @tparam T Type de l'it�rateur de sortie.
	* @param _Input Point de code UTF-32 � encoder.
	* @param _Output It�rateur de sortie pour la cha�ne UTF-32.
	* @param _Replacement Point de code de remplacement (non utilis� ici).
	* @return It�rateur de sortie pointant apr�s le point de code �crit.
	*
	* @details
	* UTF-32 est un encodage 1:1 : chaque point de code est �crit tel quel.
	*/
	template<typename T>
	static T Encode(char32_t _Input, T _Output, std::uint32_t _Replacement = 0);

	/**
	* Avance l'it�rateur vers le prochain point de code UTF-32.
	* @tparam T Type de l'it�rateur.
	* @param _Begin It�rateur de d�but.
	* @param _End It�rateur de fin.
	* @return It�rateur pointant vers le prochain point de code.
	*/
	template<typename T>
	static T Next(T _Begin, T _End);

	/**
	* Compte le nombre de points de code UTF-32 dans une plage.
	* @tparam T Type de l'it�rateur.
	* @param _Begin It�rateur de d�but.
	* @param _End It�rateur de fin.
	* @return Nombre de points de code dans la plage.
	*/
	template<typename T>
	static std::size_t Count(T _Begin, T _End);

	/**
	* Convertit une cha�ne ANSI en UTF-32.
	* @tparam In Type de l'it�rateur d'entr�e (ANSI).
	* @tparam Out Type de l'it�rateur de sortie (UTF-32).
	* @param _Begin It�rateur de d�but de la cha�ne ANSI.
	* @param _End It�rateur de fin de la cha�ne ANSI.
	* @param _Output It�rateur de sortie pour la cha�ne UTF-32.
	* @param _Locale Locale utilis�e pour la conversion.
	* @return It�rateur de sortie pointant apr�s le dernier point de code �crit.
	*
	* @details
	* Utilise `DecodeANSI` pour convertir chaque caract�re ANSI en UTF-32.
	*/
	template<typename In, typename Out>
	static Out FromANSI(In _Begin, In _End, Out _Output, const std::locale& _Locale = {});

	/**
	* Convertit une cha�ne WIDE (wchar_t) en UTF-32.
	* @tparam In Type de l'it�rateur d'entr�e (WIDE).
	* @tparam Out Type de l'it�rateur de sortie (UTF-32).
	* @param _Begin It�rateur de d�but de la cha�ne WIDE.
	* @param _End It�rateur de fin de la cha�ne WIDE.
	* @param _Output It�rateur de sortie pour la cha�ne UTF-32.
	* @return It�rateur de sortie pointant apr�s le dernier point de code �crit.
	*
	* @details
	* Utilise `DecodeWIDE` pour convertir chaque caract�re WIDE en UTF-32.
	*/
	template<typename In, typename Out>
	static Out FromWIDE(In _Begin, In _End, Out _Output);

	/**
	* Convertit une cha�ne UTF-32 en ANSI.
	* @tparam In Type de l'it�rateur d'entr�e (UTF-32).
	* @tparam Out Type de l'it�rateur de sortie (ANSI).
	* @param _Begin It�rateur de d�but de la cha�ne UTF-32.
	* @param _End It�rateur de fin de la cha�ne UTF-32.
	* @param _Output It�rateur de sortie pour la cha�ne ANSI.
	* @param _Replacement Caract�re de remplacement en cas d'erreur.
	* @param _Locale Locale utilis�e pour la conversion.
	* @return It�rateur de sortie pointant apr�s le dernier caract�re �crit.
	*
	* @details
	* Utilise `EncodeANSI` pour convertir chaque point de code UTF-32 en ANSI.
	*/
	template<typename In, typename Out>
	static Out ToANSI(In _Begin, In _End, Out _Output, char _Replacement = 0, const std::locale& _Locale = {});

	/**
	* Convertit une cha�ne UTF-32 en WIDE (wchar_t).
	* @tparam In Type de l'it�rateur d'entr�e (UTF-32).
	* @tparam Out Type de l'it�rateur de sortie (WIDE).
	* @param _Begin It�rateur de d�but de la cha�ne UTF-32.
	* @param _End It�rateur de fin de la cha�ne UTF-32.
	* @param _Output It�rateur de sortie pour la cha�ne WIDE.
	* @param _Replacement Caract�re de remplacement en cas d'erreur.
	* @return It�rateur de sortie pointant apr�s le dernier caract�re �crit.
	*
	* @details
	* Utilise `EncodeWIDE` pour convertir chaque point de code UTF-32 en WIDE.
	*/
	template<typename In, typename Out>
	static Out ToWIDE(In _Begin, In _End, Out _Output, wchar_t _Replacement = 0);

	/**
	* Convertit une cha�ne UTF-32 en UTF-8.
	* @tparam In Type de l'it�rateur d'entr�e (UTF-32).
	* @tparam Out Type de l'it�rateur de sortie (UTF-8).
	* @param _Begin It�rateur de d�but de la cha�ne UTF-32.
	* @param _End It�rateur de fin de la cha�ne UTF-32.
	* @param _Output It�rateur de sortie pour la cha�ne UTF-8.
	* @return It�rateur de sortie pointant apr�s le dernier octet �crit.
	*
	* @details
	* Utilise `UTF8::Encode` pour convertir chaque point de code UTF-32 en UTF-8.
	*/
	template<typename In, typename Out>
	static Out ToUTF8(In _Begin, In _End, Out _Output);

	/**
	* Convertit une cha�ne UTF-32 en UTF-16.
	* @tparam In Type de l'it�rateur d'entr�e (UTF-32).
	* @tparam Out Type de l'it�rateur de sortie (UTF-16).
	* @param _Begin It�rateur de d�but de la cha�ne UTF-32.
	* @param _End It�rateur de fin de la cha�ne UTF-32.
	* @param _Output It�rateur de sortie pour la cha�ne UTF-16.
	* @return It�rateur de sortie pointant apr�s le dernier caract�re �crit.
	*
	* @details
	* Utilise `UTF16::Encode` pour convertir chaque point de code UTF-32 en UTF-16.
	*/
	template<typename In, typename Out>
	static Out ToUTF16(In _Begin, In _End, Out _Output);

	/**
	* D�code un caract�re ANSI en UTF-32 en utilisant une locale.
	* @tparam T Type du caract�re ANSI (g�n�ralement `char`).
	* @param _Input Caract�re ANSI � d�coder.
	* @param _Locale Locale utilis�e pour la conversion.
	* @return Point de code UTF-32 correspondant.
	*
	* @details
	* Utilise `std::use_facet<std::ctype<wchar_t>>` pour obtenir la facette de conversion de la locale,
	* puis `facet.widen()` pour convertir le caract�re ANSI en `wchar_t`, puis en `char32_t`.
	*/
	template<typename T>
	static char32_t DecodeANSI(T _Input, const std::locale& _Locale = {});

	/**
	* D�code un caract�re WIDE (wchar_t) en UTF-32.
	* @tparam T Type du caract�re WIDE (g�n�ralement `wchar_t`).
	* @param _Input Caract�re WIDE � d�coder.
	* @return Point de code UTF-32 correspondant.
	*
	* @details
	* Sur la plupart des syst�mes, `wchar_t` est d�j� compatible avec UTF-32 (4 octets).
	* Cette fonction se contente de caster le caract�re en `char32_t`.
	*/
	template<typename T>
	static char32_t DecodeWIDE(T _Input);

	/**
	* Encode un point de code UTF-32 en ANSI en utilisant une locale.
	* @tparam T Type de l'it�rateur de sortie (ANSI).
	* @param _Codepoint Point de code UTF-32 � encoder.
	* @param _Output It�rateur de sortie pour la cha�ne ANSI.
	* @param _Remplacement Caract�re de remplacement en cas d'erreur.
	* @param _Locale Locale utilis�e pour la conversion.
	* @return It�rateur de sortie pointant apr�s le caract�re �crit.
	*
	* @details
	* Utilise `std::use_facet<std::ctype<wchar_t>>` pour obtenir la facette de conversion de la locale,
	* puis `facet.narrow()` pour convertir le point de code en `char`.
	* Si le point de code ne peut pas �tre repr�sent� en ANSI, utilise `_Remplacement`.
	*/
	template<typename T>
	static T EncodeANSI(char32_t _Codepoint, T _Output, char _Remplacement = 0, const std::locale& _Locale = {});

	/**
	* Encode un point de code UTF-32 en WIDE (wchar_t).
	* @tparam T Type de l'it�rateur de sortie (WIDE).
	* @param _Codepoint Point de code UTF-32 � encoder.
	* @param _Output It�rateur de sortie pour la cha�ne WIDE.
	* @param _Replacement Caract�re de remplacement en cas d'erreur.
	* @return It�rateur de sortie pointant apr�s le caract�re �crit.
	*
	* @details
	* - Si `wchar_t` fait 4 octets (comme sur Linux), le point de code est �crit directement.
	* - Si `wchar_t` fait 2 octets (comme sur Windows), v�rifie si le point de code est dans la plage valide pour UTF-16 (0x0000-0xD7FF ou 0xE000-0xFFFF).
	*   Si oui, l'�crit directement. Sinon, utilise `_Replacement`.
	*/
	template<typename T>
	static T EncodeWIDE(char32_t _Codepoint, T _Output, wchar_t _Replacement = 0);
};

#include "UTF.inl"