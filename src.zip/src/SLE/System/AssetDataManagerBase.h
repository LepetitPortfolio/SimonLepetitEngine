#pragma once

#include <unordered_map>
#include <cstdint>

class AssetData;

class AssetDataManagerBase
{
public:

	/**
	* Constructeur par d�faut de DataManagerBase.
	* @tparam AssetData* Type des donn�es g�r�es.
	*
	* @details
	* Initialise un objet DataManagerBase vide. Aucune allocation ou initialisation suppl�mentaire n'est n�cessaire.
	*/
	AssetDataManagerBase();

	/**
	* Destructeur de DataManagerBase.
	* @tparam AssetData* Type des donn�es g�r�es.
	*
	* @details
	* - V�rifie si la map `m_DataList` n'est pas vide.
	* - Si des donn�es sont pr�sentes, appelle `ClearAllData()` pour lib�rer la m�moire allou�e pour chaque �l�ment.
	* - Cela garantit qu'aucune fuite m�moire ne se produit lorsque l'objet DataManagerBase est d�truit.
	*/
	~AssetDataManagerBase();

	/**
	* Ajoute une donn�e � la collection.
	* @tparam AssetData Type de la donn�e.
	* @param _Data Donn�e � ajouter (doit �tre un pointeur, car on v�rifie `nullptr`).
	*
	* @details
	* - **V�rification de nullit�** : Si `_Data` est `nullptr`, la m�thode retourne imm�diatement sans rien faire.
	* - **G�n�ration de l'ID** : Utilise `reinterpret_cast<uint64_t>(_Data)` pour convertir l'adresse m�moire de `_Data` en un `uint64_t`. Cela permet d'utiliser l'adresse comme cl� unique dans la map.
	* - **Ajout � la map** : V�rifie si la cl� (ID) n'existe pas d�j� dans `m_DataList` avec `m_DataList.count(id) == 0`. Si c'est le cas, ajoute `_Data` � la map avec cette cl�.
	*/
	void AddData(AssetData* _Data);

	/**
	* Supprime une donn�e de la collection et lib�re sa m�moire.
	* @tparam AssetData* Type de la donn�e.
	* @param _Data Donn�e � supprimer (doit �tre un pointeur).
	*
	* @details
	* - **V�rification de nullit�** : Si `_Data` est `nullptr`, la m�thode retourne imm�diatement.
	* - **G�n�ration de l'ID** : Convertit l'adresse m�moire de `_Data` en `uint64_t` pour obtenir la cl�.
	* - **Recherche dans la map** : V�rifie si la cl� existe dans `m_DataList` avec `m_DataList.count(id) != 0`.
	* - **Suppression de la m�moire** :
	*   - R�cup�re le pointeur stock� dans la map (`m_DataList[id]`).
	*   - Supprime la donn�e avec `delete data`.
	*   - Supprime l'entr�e de la map avec `m_DataList.erase(id)`.
	*/
	void RemoveData(AssetData* _Data);

	/**
	* Supprime toutes les donn�es de la collection et lib�re leur m�moire.
	* @tparam AssetData* Type des donn�es.
	*
	* @details
	* - **Parcours de la map** : It�re sur toutes les entr�es de `m_DataList`.
	* - **Suppression de la m�moire** : Pour chaque entr�e, supprime la donn�e avec `delete data.second`.
	* - **Nettoyage de la map** : Appelle `m_DataList.clear()` pour vider la map.
	*/
	void ClearAllData();

	uint32_t GetDataCount() const { return static_cast<uint32_t>(m_DataList.size()); }
	std::unordered_map<uint64_t, AssetData*>*  GetData() { return &m_DataList; }

protected:

	std::unordered_map<uint64_t, AssetData*> m_DataList;
};
