#pragma once
#include "UTF.h"

#include <locale>
#include <string>
#include <vector>

#include <cstddef>
#include <cstdint>

struct  U8StringCharTraits
{
    using CharType = std::uint8_t;
    using IntType = std::char_traits<char>::int_type;
    using OffType = std::char_traits<char>::off_type;
    using PosType = std::char_traits<char>::pos_type;
    using StateType = std::char_traits<char>::state_type;

    /**
    * Assigne la valeur d'un caract�re � un autre.
    * @param _Char1 R�f�rence vers le caract�re de destination.
    * @param _Char2 Caract�re source � assigner.
    */
    static void Assign(CharType& _Char1, CharType _Char2);

    /**
    * Assigne un caract�re � une position sp�cifique dans une cha�ne.
    * @param _Str Pointeur vers la cha�ne de destination.
    * @param _Index Position dans la cha�ne o� assigner le caract�re.
    * @param _Char Caract�re � assigner.
    * @return Pointeur vers la cha�ne modifi�e.
    *
    * @details
    * Utilise `std::char_traits<char>::assign` pour effectuer l'assignation,
    * avec des conversions de type pour compatibilit�.
    */
    static CharType* Assign(CharType* _Str, std::size_t _Index, CharType _Char);

    /**
    * Compare deux caract�res pour l'�galit�.
    * @param _Char1 Premier caract�re.
    * @param _Char2 Deuxi�me caract�re.
    * @return true si les caract�res sont �gaux, false sinon.
    */
    static bool Equal(CharType _Char1, CharType _Char2);

    /**
    * Compare deux caract�res pour v�rifier si le premier est strictement inf�rieur au deuxi�me.
    * @param _Char1 Premier caract�re.
    * @param _Char2 Deuxi�me caract�re.
    * @return true si _Char1 < _Char2, false sinon.
    */
    static bool Lt(CharType _Char1, CharType _Char2);

    /**
    * D�place un bloc de caract�res d'une cha�ne source vers une cha�ne destination.
    * @param _Str1 Pointeur vers la cha�ne de destination.
    * @param _Str2 Pointeur vers la cha�ne source.
    * @param _Index Nombre de caract�res � d�placer.
    * @return Pointeur vers la cha�ne de destination.
    *
    * @details
    * Utilise `std::memmove` pour garantir un d�placement s�r (m�me si les blocs se chevauchent).
    */
    static CharType* Move(CharType* _Str1, const CharType* _Str2, std::size_t _Index);

    /**
    * Copie un bloc de caract�res d'une cha�ne source vers une cha�ne destination.
    * @param _Str1 Pointeur vers la cha�ne de destination.
    * @param _Str2 Pointeur vers la cha�ne source.
    * @param _Index Nombre de caract�res � copier.
    * @return Pointeur vers la cha�ne de destination.
    *
    * @details
    * Utilise `std::memcpy` pour une copie rapide.
    */
    static CharType* Copy(CharType* _Str1, const CharType* _Str2, std::size_t _Index);

    /**
    * Compare deux blocs de caract�res.
    * @param _Str1 Pointeur vers la premi�re cha�ne.
    * @param _Str2 Pointeur vers la deuxi�me cha�ne.
    * @param _Index Nombre de caract�res � comparer.
    * @return R�sultat de la comparaison (0 si �gaux, <0 si _Str1 < _Str2, >0 sinon).
    */
    static int Compare(const CharType* _Str1, const CharType* _Str2, std::size_t _Index);

    /**
    * Calcule la longueur d'une cha�ne de caract�res (jusqu'au caract�re nul).
    * @param _Str Pointeur vers la cha�ne.
    * @return Longueur de la cha�ne (sans le caract�re nul final).
    */
    static std::size_t Length(const CharType* _Str);

    /**
    * Trouve la premi�re occurrence d'un caract�re dans une cha�ne.
    * @param _Str Pointeur vers la cha�ne � parcourir.
    * @param _Index Nombre de caract�res � parcourir.
    * @param _Char Caract�re � rechercher.
    * @return Pointeur vers la premi�re occurrence du caract�re, ou nullptr si non trouv�.
    */
    static const CharType* Find(const CharType* _Str, std::size_t _Index, const CharType& _Char);

    /**
    * Convertit un entier de type `IntType` en `CharType`.
    * @param _Int Valeur enti�re � convertir.
    * @return Caract�re correspondant.
    */
    static CharType ToCharType(IntType _Int) noexcept;

    /**
    * Convertit un caract�re de type `CharType` en `IntType`.
    * @param _Char Caract�re � convertir.
    * @return Valeur enti�re correspondante.
    */
    static IntType ToIntType(CharType _Char) noexcept;

    /**
    * Compare deux valeurs de type `IntType` pour l'�galit�.
    * @param _Int1 Premi�re valeur.
    * @param _Int2 Deuxi�me valeur.
    * @return true si les valeurs sont �gales, false sinon.
    */
    static bool EqualIntType(IntType _Int1, IntType _Int2) noexcept;

    /**
    * Retourne la valeur sp�ciale EOF (fin de fichier).
    * @return Valeur EOF de type `IntType`.
    */
    static IntType Eof() noexcept;

    /**
    * V�rifie si une valeur de type `IntType` n'est pas EOF.
    * @param _Int Valeur � v�rifier.
    * @return true si la valeur n'est pas EOF, false sinon.
    */
    static IntType NotEof(IntType _Int) noexcept;
};

using U8String = std::basic_string<std::uint8_t>;
//using U8String = std::basic_string<std::uint8_t, U8StringCharTraits>;


class String
{
public:

    using Iterator = std::u32string::iterator;
    using ConstIterator = std::u32string::const_iterator;

    static inline const std::size_t InvalidPos{ std::u32string::npos };

	String() = default;
    String(std::nullptr_t, const std::locale & = {}) = delete;
    
    /**
    * Constructeur � partir d'un caract�re ANSI.
    * @param _ANSIChar Caract�re ANSI � convertir en UTF-32.
    * @param _Locale Locale utilis�e pour la conversion.
    */
    String(char _ANSIChar, const std::locale& _Locale = {});

    /**
    * Constructeur � partir d'un caract�re large (wchar_t).
    * @param _WideChar Caract�re large � convertir en UTF-32.
    */
    String(wchar_t _WideChar);

    /**
    * Constructeur � partir d'un caract�re UTF-32.
    * @param _UTF32Char Caract�re UTF-32.
    */
    String(char32_t _UTF32Char);

    /**
    * Constructeur � partir d'une cha�ne ANSI (C-string).
    * @param _ANSIString Cha�ne ANSI � convertir en UTF-32.
    * @param _Locale Locale utilis�e pour la conversion.
    */
    String(const char* _ANSIString, const std::locale& _Locale = {});

    /**
    * Constructeur � partir d'une cha�ne ANSI (std::string).
    * @param _ANSIString Cha�ne ANSI � convertir en UTF-32.
    * @param _Locale Locale utilis�e pour la conversion.
    */
    String(const std::string& _ANSIString, const std::locale& _Locale = {});

    /**
    * Constructeur � partir d'une cha�ne large (C-string).
    * @param _WideString Cha�ne large � convertir en UTF-32.
    */
    String(const wchar_t* _WideString);
    
    /**
    * Constructeur � partir d'une cha�ne large (std::wstring).
    * @param _WideString Cha�ne large � convertir en UTF-32.
    */
    String(const std::wstring& _WideString);
    
    /**
    * Constructeur � partir d'une cha�ne UTF-32 (C-string).
    * @param _UTF32String Cha�ne UTF-32.
    */
    String(const char32_t* _UTF32String);

    /**
    * Constructeur � partir d'une cha�ne UTF-32 (std::u32string).
    * @param _UTF32String Cha�ne UTF-32 � d�placer.
    */
    String(std::u32string _UTF32String);

    /**
    * Convertit une cha�ne UTF-8 en une cha�ne UTF-32 (repr�sent�e par la classe String).
    *
    * @tparam T Type de l'it�rateur (ex: `const char*`, `std::string::iterator`, etc.).
    * @param _Begin It�rateur pointant vers le d�but de la cha�ne UTF-8.
    * @param _End It�rateur pointant vers la fin de la cha�ne UTF-8.
    * @return String Cha�ne convertie en UTF-32.
    *
    * @details
    * - Cr�e une nouvelle instance de `String` (UTF-32).
    * - Utilise la fonction statique `UTF8::ToUTF32` pour convertir la plage [_Begin, _End) en UTF-32.
    * - Les caract�res convertis sont ins�r�s dans `outStr.m_String` via `std::back_inserter`.
    * - Retourne la cha�ne r�sultante.
    *
    * @note
    * `UTF8::ToUTF32` est probablement une fonction utilitaire qui g�re la conversion des s�quences UTF-8
    * (1 � 4 octets par caract�re) vers UTF-32 (4 octets par caract�re).
    */
    template <typename T>
    static String FromUTF8(T _Begin, T _End);

    /**
    * Convertit une cha�ne UTF-16 en une cha�ne UTF-32 (repr�sent�e par la classe String).
    *
    * @tparam T Type de l'it�rateur (ex: `const char16_t*`, `std::u16string::iterator`, etc.).
    * @param _Begin It�rateur pointant vers le d�but de la cha�ne UTF-16.
    * @param _End It�rateur pointant vers la fin de la cha�ne UTF-16.
    * @return String Cha�ne convertie en UTF-32.
    *
    * @details
    * - Cr�e une nouvelle instance de `String` (UTF-32).
    * - Utilise la fonction statique `UTF16::ToUTF32` pour convertir la plage [_Begin, _End) en UTF-32.
    * - Les caract�res convertis sont ins�r�s dans `outStr.m_String` via `std::back_inserter`.
    * - Retourne la cha�ne r�sultante.
    *
    * @note
    * `UTF16::ToUTF32` g�re la conversion des paires de substitution UTF-16 (pour les caract�res hors du plan multilingue de base)
    * vers UTF-32.
    */
    template <typename T>
    static String FromUTF16(T _Begin, T _End);

    /**
    * Cr�e une cha�ne UTF-32 (repr�sent�e par la classe String) � partir d'une plage d'it�rateurs UTF-32.
    *
    * @tparam T Type de l'it�rateur (ex: `const char32_t*`, `std::u32string::iterator`, etc.).
    * @param _Begin It�rateur pointant vers le d�but de la cha�ne UTF-32.
    * @param _End It�rateur pointant vers la fin de la cha�ne UTF-32.
    * @return String Cha�ne UTF-32 copi�e.
    *
    * @details
    * - Cr�e une nouvelle instance de `String`.
    * - Copie directement la plage [_Begin, _End) dans `outStr.m_String` via `assign`.
    * - Retourne la cha�ne r�sultante.
    *
    * @note
    * Aucune conversion n'est n�cessaire ici, car UTF-32 est d�j� le format interne de `String`.
    * Cette fonction est une simple copie.
    */
    template <typename T>
    static String FromUTF32(T _Begin, T _End);

    
    /**
    * Conversion implicite vers std::string (ANSI).
    * @return Cha�ne ANSI �quivalente.
    */
    operator std::string() const;

    /**
    * Conversion implicite vers std::wstring (large).
    * @return Cha�ne large �quivalente.
    */
    operator std::wstring() const;

    /**
    * Convertit la cha�ne UTF-32 en ANSI (std::string).
    * @param _Locale Locale utilis�e pour la conversion.
    * @return Cha�ne ANSI �quivalente.
    */
    std::string ToANSIString(const std::locale& _Locale = {}) const;
    
    /**
    * Convertit la cha�ne UTF-32 en large (std::wstring).
    * @return Cha�ne large �quivalente.
    */
    std::wstring ToWideString() const;

    /**
    * Convertit la cha�ne UTF-32 en UTF-8.
    * @return Cha�ne UTF-8 �quivalente.
    */
    U8String ToUTF8() const;

    /**
    * Convertit la cha�ne UTF-32 en UTF-16.
    * @return Cha�ne UTF-16 �quivalente.
    */
    std::u16string ToUTF16() const;
    
    /**
    * Retourne la cha�ne UTF-32 sous-jacente.
    * @return R�f�rence vers m_String.
    */
    std::u32string ToUTF32() const;

    
    /**
    * Ajoute une cha�ne � la cha�ne courante.
    * @param _Right Cha�ne � ajouter.
    * @return R�f�rence vers la cha�ne courante.
    */
    String& operator+= (const String& _Right);

    /**
    * Concat�ne deux cha�nes.
    * @param _Right Cha�ne � concat�ner.
    * @return Nouvelle cha�ne r�sultat de la concat�nation.
    */
    String operator+ (const String& _Right);

    
    /**
    * Acc�s en lecture seule � un caract�re de la cha�ne.
    * @param _Index Index du caract�re.
    * @return Caract�re � la position _Index.
    * @throws assert Si l'index est hors limites.
    */
    char32_t operator[](std::size_t _Index) const;

    /**
    * Acc�s en lecture/�criture � un caract�re de la cha�ne.
    * @param _Index Index du caract�re.
    * @return R�f�rence vers le caract�re � la position _Index.
    * @throws assert Si l'index est hors limites.
    */
    char32_t& operator[](std::size_t _Index);

    /**
    * Efface tout le contenu de la cha�ne.
    */
    void Clear();

    /**
    * Retourne la taille de la cha�ne.
    * @return Nombre de caract�res dans la cha�ne.
    */
    std::size_t GetSize() const;

    /**
    * V�rifie si la cha�ne est vide.
    * @return true si la cha�ne est vide, false sinon.
    */
    bool IsEmpty() const;

    /**
    * Supprime une partie de la cha�ne.
    * @param _Position Position de d�part de la suppression.
    * @param _Count Nombre de caract�res � supprimer.
    */
    void Erase(std::size_t _Position, std::size_t _Count = 1);

    /**
    * Ins�re une cha�ne � une position donn�e.
    * @param _Position Position d'insertion.
    * @param _Str Cha�ne � ins�rer.
    */
    void Insert(std::size_t _Position, const String& _Str);

    /**
    * Trouve la premi�re occurrence d'une sous-cha�ne.
    * @param _Str Sous-cha�ne � rechercher.
    * @param _Start Position de d�part de la recherche.
    * @return Position de la premi�re occurrence, ou `InvalidPos` si non trouv�e.
    */
    std::size_t Find(const String& _Str, std::size_t _Start = 0) const;

    /**
    * Remplace une partie de la cha�ne par une autre cha�ne.
    * @param _Position Position de d�part du remplacement.
    * @param _Length Nombre de caract�res � remplacer.
    * @param _ReplaceWith Cha�ne de remplacement.
    */
    void Replace(std::size_t _Position, std::size_t _Length, const String& _ReplaceWith);
    
    /**
    * Remplace toutes les occurrences d'une sous-cha�ne par une autre.
    * @param _SearchFor Sous-cha�ne � rechercher.
    * @param _ReplaceWith Cha�ne de remplacement.
    */
    void Replace(const String& _SearchFor, const String& _ReplaceWith);

    /**
    * Extrait une sous-cha�ne.
    * @param _Position Position de d�part.
    * @param _Length Longueur de la sous-cha�ne.
    * @return Nouvelle cha�ne contenant la sous-cha�ne extraite.
    */
    String SubString(std::size_t _Position, std::size_t _Legth = InvalidPos) const;

    /**
    * Divise une cha�ne en sous-cha�nes en utilisant un d�limiteur.
    * @param _Str Cha�ne � diviser.
    * @param _Delimiter D�limiteur.
    * @return Vecteur de sous-cha�nes.
    */
    static std::vector<String> Split(const String& _Str, const String& _Delimiter);

    /**
    * Divise la cha�ne courante en sous-cha�nes en utilisant un d�limiteur.
    * @param _Delimiter D�limiteur.
    * @return Vecteur de sous-cha�nes.
    */
    std::vector<String> Split(const String& _Delimiter);
    
    /**
    * Retourne un pointeur vers les donn�es de la cha�ne.
    * @return Pointeur vers le premier caract�re de la cha�ne.
    */
    const char32_t* GetData() const;

    /**
    * Retourne un it�rateur vers le d�but de la cha�ne.
    * @return It�rateur vers le premier caract�re.
    */
    Iterator Begin();

    /**
    * Retourne un it�rateur constant vers le d�but de la cha�ne.
    * @return It�rateur constant vers le premier caract�re.
    */
    ConstIterator Begin() const;

    /**
    * Retourne un it�rateur vers la fin de la cha�ne.
    * @return It�rateur vers la position apr�s le dernier caract�re.
    */
    Iterator End();

    /**
    * Retourne un it�rateur constant vers la fin de la cha�ne.
    * @return It�rateur constant vers la position apr�s le dernier caract�re.
    */
    ConstIterator End() const;

private:

    std::u32string m_String;

    /**
    * Compare deux cha�nes pour l'�galit�.
    * @param _Left Premi�re cha�ne.
    * @param _Right Deuxi�me cha�ne.
    * @return true si les cha�nes sont �gales, false sinon.
    */
    friend bool operator==(const String& _Left, const String& _Right);
    
    /**
    * Compare deux cha�nes pour v�rifier si la premi�re est strictement inf�rieure � la deuxi�me.
    * @param _Left Premi�re cha�ne.
    * @param _Right Deuxi�me cha�ne.
    * @return true si _Left < _Right, false sinon.
    */
    friend bool operator<(const String& _Left, const String& _Right);
};

template<typename T>
inline String String::FromUTF8(T _Begin, T _End)
{
    String outStr;
    UTF8::ToUTF32(_Begin, _End, std::back_inserter(outStr.m_String));
    return outStr;
}

template<typename T>
inline String String::FromUTF16(T _Begin, T _End)
{
    String outStr;
    UTF16::ToUTF32(_Begin, _End, std::back_inserter(outStr.m_String));
    return outStr;
}

template<typename T>
inline String String::FromUTF32(T _Begin, T _End)
{
    String outStr;
    outStr.m_String.assign(_Begin, _End);
    return outStr;
}
